import React from 'react';
import { DollarSign, ShoppingBag, CreditCard, ShoppingCart, TrendingUp, Award, Layers } from 'lucide-react';
import { MetricSummary } from '../types';

interface KPICardsProps {
  metrics: MetricSummary;
  onFilterByProduct?: (productName: string) => void;
  onFilterByPayment?: (paymentName: string) => void;
}

export const KPICards: React.FC<KPICardsProps> = ({
  metrics,
  onFilterByProduct,
  onFilterByPayment,
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      
      {/* 1. Total Revenue Card */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl hover:bg-white/[0.08] hover:border-white/20 transition-all relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl group-hover:bg-indigo-500/20 transition-all" />
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Revenue</p>
            <h3 className="text-2xl font-bold text-white mt-1 tracking-tight">
              ${metrics.totalRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h3>
          </div>
          <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-xl backdrop-blur-md">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1 text-slate-300">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            Avg Order: <strong className="text-white">${metrics.avgOrderValue.toFixed(2)}</strong>
          </span>
          <span>
            {metrics.totalItemsSold} Items
          </span>
        </div>
      </div>

      {/* 2. Total Orders & Basket Density */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl hover:bg-white/[0.08] hover:border-white/20 transition-all relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-full blur-2xl group-hover:bg-purple-500/20 transition-all" />
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Unique Orders</p>
            <h3 className="text-2xl font-bold text-white mt-1 tracking-tight">
              {metrics.totalUniqueOrders}
            </h3>
          </div>
          <div className="p-3 bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 rounded-xl backdrop-blur-md">
            <ShoppingCart className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            Multi-Item Orders:
          </span>
          <strong className="text-indigo-300 font-semibold">
            {metrics.multiItemOrdersCount} ({metrics.multiItemOrdersPercent.toFixed(0)}%)
          </strong>
        </div>
      </div>

      {/* 3. Top Product by Revenue */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl hover:bg-white/[0.08] hover:border-white/20 transition-all relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl group-hover:bg-amber-500/20 transition-all" />
        <div className="flex items-start justify-between">
          <div className="max-w-[75%]">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Top Revenue Product</p>
            <h3
              onClick={() => onFilterByProduct && metrics.topProductByRevenue.name !== 'N/A' && onFilterByProduct(metrics.topProductByRevenue.name)}
              className="text-base font-bold text-amber-300 hover:text-amber-200 mt-1 truncate cursor-pointer transition-colors"
              title={`Click to filter by ${metrics.topProductByRevenue.name}`}
            >
              {metrics.topProductByRevenue.name}
            </h3>
          </div>
          <div className="p-3 bg-amber-500/15 border border-amber-500/30 text-amber-400 rounded-xl shrink-0 backdrop-blur-md">
            <Award className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <span>Revenue: <strong className="text-white">${metrics.topProductByRevenue.revenue.toLocaleString()}</strong></span>
          <span>{metrics.topProductByRevenue.units} Sold</span>
        </div>
      </div>

      {/* 4. Top Payment Method */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl hover:bg-white/[0.08] hover:border-white/20 transition-all relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/10 rounded-full blur-2xl group-hover:bg-rose-500/20 transition-all" />
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Top Payment Type</p>
            <h3
              onClick={() => onFilterByPayment && metrics.topPaymentMethod.name !== 'N/A' && onFilterByPayment(metrics.topPaymentMethod.name)}
              className="text-2xl font-bold text-white mt-1 cursor-pointer hover:text-rose-300 transition-colors tracking-tight"
              title={`Click to filter by ${metrics.topPaymentMethod.name}`}
            >
              {metrics.topPaymentMethod.name}
            </h3>
          </div>
          <div className="p-3 bg-rose-500/15 border border-rose-500/30 text-rose-400 rounded-xl backdrop-blur-md">
            <CreditCard className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <span>Volume: <strong className="text-white">{metrics.topPaymentMethod.count} txns</strong></span>
          <span>${metrics.topPaymentMethod.revenue.toLocaleString()}</span>
        </div>
      </div>

    </div>
  );
};
