import React, { useState } from 'react';
import { ProductPerformance, ProductCoOccurrence } from '../types';
import { ShoppingBag, ArrowUpDown, Search, Percent, DollarSign, Package, Layers, ExternalLink } from 'lucide-react';
import { ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, ZAxis, Tooltip, CartesianGrid, Cell } from 'recharts';

interface ProductAnalyticsProps {
  products: ProductPerformance[];
  coOccurrences: ProductCoOccurrence[];
  onFilterByProduct: (productName: string) => void;
}

export const ProductAnalytics: React.FC<ProductAnalyticsProps> = ({
  products,
  coOccurrences,
  onFilterByProduct,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<'revenue' | 'unitsSold' | 'avgPrice' | 'revenueSharePercent'>('revenue');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const handleSort = (field: 'revenue' | 'unitsSold' | 'avgPrice' | 'revenueSharePercent') => {
    if (sortField === field) {
      setSortDirection(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const filteredProducts = products
    .filter(p => p.product.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => {
      const modifier = sortDirection === 'asc' ? 1 : -1;
      return (a[sortField] - b[sortField]) * modifier;
    });

  // Data for Scatter Chart: Price vs Units Sold with Revenue as bubble size
  const scatterData = products.map(p => ({
    name: p.product,
    x: p.avgPrice,
    y: p.unitsSold,
    z: p.revenue,
  }));

  const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#f43f5e', '#8b5cf6', '#06b6d4', '#ec4899', '#3b82f6'];

  return (
    <div className="space-y-6">
      
      {/* 1. Header & Price vs Volume Scatter Plot */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <div className="lg:col-span-7 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-indigo-400" />
              Price Point vs Units Sold Analysis
            </h3>
            <p className="text-xs text-slate-400">
              Identify high-margin luxury items ($145-$175) vs high-volume everyday workwear & denim ($58-$98)
            </p>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 10, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />
                <XAxis
                  type="number"
                  dataKey="x"
                  name="Unit Price"
                  unit="$"
                  stroke="#94a3b8"
                  fontSize={11}
                  domain={[50, 190]}
                />
                <YAxis
                  type="number"
                  dataKey="y"
                  name="Units Sold"
                  stroke="#94a3b8"
                  fontSize={11}
                />
                <ZAxis type="number" dataKey="z" range={[80, 400]} name="Revenue" unit="$" />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    borderColor: 'rgba(255, 255, 255, 0.15)',
                    borderRadius: '16px',
                    color: '#f8fafc',
                    fontSize: '12px',
                    backdropFilter: 'blur(12px)',
                  }}
                  formatter={(val: any, name: string) => {
                    if (name === 'Unit Price') return [`$${val}`, name];
                    if (name === 'Units Sold') return [`${val} units`, name];
                    if (name === 'Revenue') return [`$${val.toLocaleString()}`, name];
                    return [val, name];
                  }}
                  labelFormatter={() => ''}
                />
                <Scatter
                  name="Products"
                  data={scatterData}
                  fill="#8884d8"
                  cursor="pointer"
                  onClick={(entry) => onFilterByProduct(entry.name)}
                >
                  {scatterData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          </div>

          {/* Product Color Key & Legend Grid */}
          <div className="pt-3 border-t border-white/10 space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-400" />
              Scatter Chart Product Color Key
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {products.map((p, index) => {
                const color = COLORS[index % COLORS.length];
                return (
                  <div
                    key={p.product}
                    onClick={() => onFilterByProduct(p.product)}
                    className="flex items-center justify-between p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 cursor-pointer transition-all backdrop-blur-md group"
                    title={`Filter by ${p.product}`}
                  >
                    <div className="flex items-center gap-2 min-w-0 pr-1">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0 shadow-sm" style={{ backgroundColor: color }} />
                      <span className="text-xs font-semibold text-slate-200 truncate group-hover:text-indigo-300 transition-colors">
                        {p.product}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 shrink-0">{color}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Multi-Item Cross-Sell Basket Co-occurrence Table (5 cols) */}
        <div className="lg:col-span-5 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400" />
              Frequently Bought Together
            </h3>
            <p className="text-xs text-slate-400">
              Product pairs co-purchased in multi-item orders
            </p>
          </div>

          <div className="space-y-2 overflow-y-auto max-h-72 pr-1 custom-scrollbar">
            {coOccurrences.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-500">
                No multi-item order pairings in current filter.
              </div>
            ) : (
              coOccurrences.map((pair, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-white/5 border border-white/10 rounded-xl flex items-center justify-between gap-2 hover:bg-white/10 transition-colors backdrop-blur-md"
                >
                  <div className="flex flex-col text-xs space-y-1">
                    <span className="font-semibold text-slate-200">{pair.productA}</span>
                    <span className="text-slate-400 text-[11px]">+ {pair.productB}</span>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-lg backdrop-blur-md">
                      {pair.coOccurrences} order{pair.coOccurrences > 1 ? 's' : ''}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* 2. Detailed Product Performance Table */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
          <div>
            <h3 className="text-base font-bold text-white">
              Product Performance Catalog ({filteredProducts.length} Products)
            </h3>
            <p className="text-xs text-slate-400">
              Comprehensive revenue breakdown, unit prices, and revenue share
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-indigo-400" />
            <input
              type="text"
              placeholder="Search product name..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-400 backdrop-blur-md"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-3">Product Name</th>
                <th
                  onClick={() => handleSort('revenue')}
                  className="py-3 px-3 cursor-pointer hover:text-slate-200 text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    Revenue
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('unitsSold')}
                  className="py-3 px-3 cursor-pointer hover:text-slate-200 text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    Units Sold
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('avgPrice')}
                  className="py-3 px-3 cursor-pointer hover:text-slate-200 text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    Unit Price
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('revenueSharePercent')}
                  className="py-3 px-3 cursor-pointer hover:text-slate-200 text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    Share %
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10 text-slate-300">
              {filteredProducts.map((p, idx) => {
                const color = COLORS[products.findIndex(prod => prod.product === p.product) % COLORS.length] || '#6366f1';
                return (
                  <tr key={p.product} className="hover:bg-white/5 transition-colors">
                    <td className="py-3 px-3 font-semibold text-white">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: color }} />
                        <span>{p.product}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right font-bold text-emerald-400">
                      ${p.revenue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-3 text-right font-medium">
                      {p.unitsSold}
                    </td>
                    <td className="py-3 px-3 text-right text-slate-400">
                      ${p.avgPrice.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-16 bg-white/10 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="h-1.5 rounded-full"
                            style={{ width: `${Math.min(p.revenueSharePercent * 5, 100)}%`, backgroundColor: color }}
                          />
                        </div>
                        <span className="font-medium text-slate-200 w-10 text-right">{p.revenueSharePercent}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => onFilterByProduct(p.product)}
                        className="px-2.5 py-1 text-[11px] font-medium bg-indigo-500/20 hover:bg-indigo-600 text-indigo-300 hover:text-white rounded-xl border border-indigo-500/30 transition-all backdrop-blur-md"
                      >
                        Filter
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
