import React from 'react';
import { LayoutDashboard, ShoppingBag, CreditCard, BarChart2, Table, Upload, Download, RefreshCw, Layers, FileSpreadsheet } from 'lucide-react';
import { DashboardView, SalesRecord } from '../types';
import { exportToCSV } from '../data/initialData';

interface HeaderProps {
  currentView: DashboardView;
  onViewChange: (view: DashboardView) => void;
  totalRecordsCount: number;
  filteredRecordsCount: number;
  totalRevenue: number;
  records: SalesRecord[];
  onOpenImportModal: () => void;
  onResetFilters: () => void;
  hasActiveFilters: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onViewChange,
  totalRecordsCount,
  filteredRecordsCount,
  totalRevenue,
  records,
  onOpenImportModal,
  onResetFilters,
  hasActiveFilters,
}) => {
  const handleExportCSV = () => {
    const csvContent = exportToCSV(records);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `sales_data_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const navItems: { id: DashboardView; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'products', label: 'Product Intelligence', icon: <ShoppingBag className="w-4 h-4" /> },
    { id: 'payment', label: 'Payment & Orders', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'custom', label: 'Chart Playground', icon: <BarChart2 className="w-4 h-4" /> },
    { id: 'table', label: 'Data Table', icon: <Table className="w-4 h-4" /> },
  ];

  return (
    <header className="bg-white/5 backdrop-blur-2xl border-b border-white/10 text-white sticky top-0 z-40 shadow-xl shadow-black/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Branding & Action Row */}
        <div className="flex flex-col md:flex-row md:items-center justify-between py-4 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-500/20 border border-indigo-400/30 rounded-2xl flex items-center justify-center text-indigo-400 shadow-lg shadow-indigo-500/10 backdrop-blur-md">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white">
                  Sales & Orders Analytics
                </h1>
                <span className="px-2.5 py-0.5 text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 rounded-full backdrop-blur-md">
                  Live Stream
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                <span>Showing <strong className="text-white">{filteredRecordsCount}</strong> of <strong className="text-white">{totalRecordsCount}</strong> items</span>
                <span>•</span>
                <span>Filtered Total: <strong className="text-emerald-400">${totalRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></span>
              </p>
            </div>
          </div>

          {/* Global Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {hasActiveFilters && (
              <button
                onClick={onResetFilters}
                className="flex items-center gap-1.5 text-xs font-medium px-3.5 py-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 rounded-xl border border-amber-500/30 transition-all backdrop-blur-md"
                title="Reset all active filters"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reset Filters
              </button>
            )}

            <button
              onClick={onOpenImportModal}
              className="flex items-center gap-1.5 text-xs font-semibold px-4 py-2 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded-xl border border-indigo-500/30 transition-all backdrop-blur-md shadow-sm"
            >
              <FileSpreadsheet className="w-4 h-4 text-indigo-400" />
              Upload CSV / Sheet
            </button>

            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 text-xs font-medium px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-lg shadow-indigo-600/30 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
          </div>
        </div>

        {/* Navigation Tabs Row */}
        <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar border-t border-white/10 pt-1">
          {navItems.map((item) => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-t-xl transition-all whitespace-nowrap border-b-2 ${
                  isActive
                    ? 'border-indigo-400 text-indigo-300 bg-white/10 font-semibold shadow-inner'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
