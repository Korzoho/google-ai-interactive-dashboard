import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Upload,
  RefreshCw,
  FileText,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Settings2,
  Sparkles,
  ArrowRight,
  Database
} from 'lucide-react';
import { SalesRecord } from '../types';
import { RAW_CSV_DATA } from '../data/initialData';
import {
  ColumnMapping,
  ParseResult,
  parseSpreadsheetFile,
  parseSpreadsheetText,
  convertRowsToSalesRecords,
} from '../utils/fileParser';

interface ImportDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportRecords: (records: SalesRecord[]) => void;
  onRestoreDefaultData: () => void;
  preloadedFile?: File | null;
}

export const ImportDataModal: React.FC<ImportDataModalProps> = ({
  isOpen,
  onClose,
  onImportRecords,
  onRestoreDefaultData,
  preloadedFile,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'upload' | 'text'>('upload');
  const [isDragging, setIsDragging] = useState(false);
  const [rawInputText, setRawInputText] = useState('');
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({
    orderNumberCol: '',
    productCol: '',
    priceCol: '',
    dateCol: '',
    paymentMethodCol: '',
  });
  const [parsedRecords, setParsedRecords] = useState<SalesRecord[]>([]);
  const [errorMsg, setErrorMsg] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // If a file was dropped on the header/page and passed in
  useEffect(() => {
    if (preloadedFile) {
      handleFileSelected(preloadedFile);
    }
  }, [preloadedFile]);

  // Process a File
  const handleFileSelected = async (file: File) => {
    setIsProcessing(true);
    setErrorMsg('');
    try {
      const result = await parseSpreadsheetFile(file);
      if (result.totalRows === 0) {
        setErrorMsg('The uploaded file appears to be empty or missing data rows.');
        setParseResult(null);
        setParsedRecords([]);
      } else {
        setParseResult(result);
        setColumnMapping(result.suggestedMapping);
        setParsedRecords(result.records);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(`Failed to parse file "${file.name}". Please ensure it's a valid CSV or Excel file.`);
      setParseResult(null);
      setParsedRecords([]);
    } finally {
      setIsProcessing(false);
    }
  };

  // Process raw text input
  const handleTextChange = (text: string) => {
    setRawInputText(text);
    if (!text.trim()) {
      setParseResult(null);
      setParsedRecords([]);
      setErrorMsg('');
      return;
    }

    try {
      const result = parseSpreadsheetText(text);
      if (result.totalRows === 0) {
        setErrorMsg('No valid rows found. Please check your CSV column headers and rows.');
        setParseResult(null);
        setParsedRecords([]);
      } else {
        setErrorMsg('');
        setParseResult(result);
        setColumnMapping(result.suggestedMapping);
        setParsedRecords(result.records);
      }
    } catch (err: any) {
      setErrorMsg('Failed to parse text. Check format for proper CSV structure.');
      setParseResult(null);
      setParsedRecords([]);
    }
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      handleFileSelected(files[0]);
    }
  };

  // Column mapping change handler
  const handleMappingChange = (field: keyof ColumnMapping, selectedHeader: string) => {
    const updatedMapping = { ...columnMapping, [field]: selectedHeader };
    setColumnMapping(updatedMapping);

    if (parseResult) {
      const updatedRecords = convertRowsToSalesRecords(parseResult.rawRows, updatedMapping);
      setParsedRecords(updatedRecords);
    }
  };

  const handleLoadSampleText = () => {
    setActiveTab('text');
    handleTextChange(RAW_CSV_DATA);
  };

  const handleRestoreDefaultClick = () => {
    onRestoreDefaultData();
    onClose();
  };

  const handleConfirmImport = () => {
    if (parsedRecords.length > 0) {
      onImportRecords(parsedRecords);
      onClose();
    }
  };

  // Calculate quick metrics for preview
  const previewRevenue = parsedRecords.reduce((acc, r) => acc + r.price, 0);
  const uniqueProductsCount = new Set(parsedRecords.map(r => r.product)).size;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto custom-scrollbar">
      <div className="bg-slate-900/95 border border-white/15 rounded-3xl w-full max-w-3xl shadow-2xl p-6 sm:p-7 space-y-6 backdrop-blur-2xl animate-in fade-in zoom-in duration-200 my-auto">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/20 text-indigo-300 rounded-2xl border border-indigo-500/30 shadow-inner">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Upload CSV or Excel Sheet
                <span className="text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Instant Analytics
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Upload any sales spreadsheet (.xlsx, .xls, .csv, .tsv) to get immediate charts, KPIs, and reports.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Mode Tabs */}
        <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3">
          <div className="flex items-center bg-white/5 p-1 rounded-2xl border border-white/10 text-xs text-slate-300 backdrop-blur-md">
            <button
              onClick={() => setActiveTab('upload')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-medium transition-all ${
                activeTab === 'upload'
                  ? 'bg-indigo-600 text-white font-semibold shadow-md'
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              <Upload className="w-3.5 h-3.5" /> File Upload (.xlsx, .csv)
            </button>
            <button
              onClick={() => setActiveTab('text')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-medium transition-all ${
                activeTab === 'text'
                  ? 'bg-indigo-600 text-white font-semibold shadow-md'
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              <FileText className="w-3.5 h-3.5" /> Raw CSV / Text Input
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleLoadSampleText}
              className="text-xs text-indigo-300 hover:text-indigo-200 font-medium hover:underline flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" /> Sample Data
            </button>
            <span className="text-slate-600">•</span>
            <button
              onClick={handleRestoreDefaultClick}
              className="text-xs text-amber-300 hover:text-amber-200 font-medium hover:underline flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Reset Default
            </button>
          </div>
        </div>

        {/* Tab 1: File Upload Drag and Drop Zone */}
        {activeTab === 'upload' && (
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer flex flex-col items-center justify-center space-y-3 ${
              isDragging
                ? 'border-indigo-400 bg-indigo-500/15 scale-[1.01]'
                : 'border-white/15 hover:border-indigo-400/60 bg-white/[0.02] hover:bg-white/[0.05]'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleFileSelected(e.target.files[0]);
                }
              }}
              accept=".csv,.xlsx,.xls,.tsv,.txt"
              className="hidden"
            />

            <div className="p-4 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20 shadow-inner">
              <Upload className="w-8 h-8 animate-pulse" />
            </div>

            <div>
              <p className="text-sm font-bold text-white">
                Drag & Drop your CSV or Excel file here
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Supports <span className="text-indigo-300 font-mono">.csv, .xlsx, .xls, .tsv, .txt</span> files up to 50MB
              </p>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                fileInputRef.current?.click();
              }}
              className="px-4 py-2 bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-semibold rounded-xl shadow-md border border-indigo-400/30 transition-all"
            >
              Select File from Computer
            </button>
          </div>
        )}

        {/* Tab 2: Raw CSV Text Input */}
        {activeTab === 'text' && (
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span>Paste Raw CSV or Tab-Separated Content</span>
              <span className="text-slate-500 font-mono text-[11px]">Columns separated by commas or tabs</span>
            </label>
            <textarea
              rows={6}
              value={rawInputText}
              onChange={e => handleTextChange(e.target.value)}
              placeholder={`Order Number,Product,Price,Date,Payment Method\nORD-2025-01,Tailored Linen Suit,$240.00,2025-09-01,Credit Card\nORD-2025-02,Silk Blend Scarf,$65.00,2025-09-02,eWallet...`}
              className="w-full bg-slate-950/80 border border-white/10 rounded-2xl p-3.5 text-slate-100 font-mono text-xs focus:outline-none focus:border-indigo-400 backdrop-blur-md custom-scrollbar"
            />
          </div>
        )}

        {/* Loading Spinner */}
        {isProcessing && (
          <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs rounded-2xl flex items-center justify-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>Parsing spreadsheet rows and detecting column headers...</span>
          </div>
        )}

        {/* Error Feedback */}
        {errorMsg && (
          <div className="p-4 bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs rounded-2xl flex items-center gap-3 backdrop-blur-md">
            <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Column Mapping & Preview Section when parse succeeds */}
        {parseResult && parseResult.headers.length > 0 && (
          <div className="space-y-4 border-t border-white/10 pt-4">
            
            {/* Success Summary Header */}
            <div className="flex flex-wrap items-center justify-between bg-emerald-500/10 border border-emerald-500/25 rounded-2xl p-3.5 gap-3 text-xs">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <span className="font-bold text-white">
                    Parsed {parsedRecords.length} sales records
                  </span>
                  <span className="text-slate-400 block text-[11px]">
                    From {parseResult.fileName || 'Spreadsheet'} • Total Revenue: <strong className="text-emerald-300">${previewRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 font-mono text-[11px] text-slate-300 bg-white/5 px-2.5 py-1 rounded-xl border border-white/10">
                <Database className="w-3.5 h-3.5 text-indigo-400" />
                <span>{uniqueProductsCount} Unique Products</span>
              </div>
            </div>

            {/* Smart Column Mapping Configurator */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3 backdrop-blur-md">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Settings2 className="w-4 h-4" /> Smart Column Mapping
                </h4>
                <span className="text-[11px] text-slate-400">
                  Auto-detected headers matched below. Adjust if needed:
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                
                {/* 1. Order Number */}
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                    Order Number / ID
                  </label>
                  <select
                    value={columnMapping.orderNumberCol}
                    onChange={(e) => handleMappingChange('orderNumberCol', e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-400"
                  >
                    {parseResult.headers.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Product Name */}
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                    Product / Item Name
                  </label>
                  <select
                    value={columnMapping.productCol}
                    onChange={(e) => handleMappingChange('productCol', e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-400"
                  >
                    {parseResult.headers.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 3. Price / Amount */}
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                    Price / Amount ($)
                  </label>
                  <select
                    value={columnMapping.priceCol}
                    onChange={(e) => handleMappingChange('priceCol', e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-400"
                  >
                    {parseResult.headers.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 4. Date */}
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                    Transaction Date
                  </label>
                  <select
                    value={columnMapping.dateCol}
                    onChange={(e) => handleMappingChange('dateCol', e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-400"
                  >
                    {parseResult.headers.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 5. Payment Method */}
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                    Payment Method
                  </label>
                  <select
                    value={columnMapping.paymentMethodCol}
                    onChange={(e) => handleMappingChange('paymentMethodCol', e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-400"
                  >
                    {parseResult.headers.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>

              </div>
            </div>

            {/* Top 5 Rows Live Preview */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                Parsed Data Preview (First 5 Rows)
              </label>
              <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-950/60">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-white/5 text-slate-400 font-semibold uppercase text-[10px] tracking-wider border-b border-white/10">
                      <th className="py-2 px-3">Order #</th>
                      <th className="py-2 px-3">Product</th>
                      <th className="py-2 px-3 text-right">Price</th>
                      <th className="py-2 px-3 text-center">Date</th>
                      <th className="py-2 px-3">Payment</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10 text-slate-300">
                    {parsedRecords.slice(0, 5).map((r, i) => (
                      <tr key={i} className="hover:bg-white/5">
                        <td className="py-2 px-3 font-mono text-indigo-300 font-medium">{r.orderNumber}</td>
                        <td className="py-2 px-3 font-semibold text-white">{r.product}</td>
                        <td className="py-2 px-3 text-right font-bold text-emerald-400">${r.price.toFixed(2)}</td>
                        <td className="py-2 px-3 text-center font-mono text-slate-400">{r.date}</td>
                        <td className="py-2 px-3">
                          <span className="px-2 py-0.5 text-[10px] rounded-full bg-white/5 border border-white/10 text-slate-300 font-medium">
                            {r.paymentMethod}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-white/10">
          <p className="text-xs text-slate-500">
            {parsedRecords.length > 0
              ? `Ready to visualize ${parsedRecords.length} records.`
              : 'Select a file to begin.'}
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 font-medium text-xs rounded-xl border border-white/10 transition-all backdrop-blur-md"
            >
              Cancel
            </button>
            <button
              disabled={parsedRecords.length === 0}
              onClick={handleConfirmImport}
              className="flex items-center gap-1.5 px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all backdrop-blur-md"
            >
              <span>Import & Visualize Dataset</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
