import React, { useState } from 'react';
import { SalesRecord } from '../types';
import { Search, ArrowUpDown, Plus, Edit2, Trash2, Check, X, Download, ChevronLeft, ChevronRight, Layers } from 'lucide-react';
import { exportToCSV } from '../data/initialData';

interface DataExplorerTableProps {
  records: SalesRecord[];
  onUpdateRecord: (updatedRecord: SalesRecord) => void;
  onDeleteRecord: (id: string) => void;
  onAddRecord: (newRecord: Omit<SalesRecord, 'id'>) => void;
}

export const DataExplorerTable: React.FC<DataExplorerTableProps> = ({
  records,
  onUpdateRecord,
  onDeleteRecord,
  onAddRecord,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof SalesRecord>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  // Editing row state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<SalesRecord>>({});

  // Adding new row state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newRow, setNewRow] = useState({
    orderNumber: 'TT-1099',
    product: 'Slim-Fit Denim Jeans',
    price: 88,
    date: new Date().toISOString().slice(0, 10),
    paymentMethod: 'Credit Card',
  });

  const handleSort = (field: keyof SalesRecord) => {
    if (sortField === field) {
      setSortDirection(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Filter & Sort
  const filtered = records.filter(r => {
    const q = searchTerm.toLowerCase();
    return (
      r.orderNumber.toLowerCase().includes(q) ||
      r.product.toLowerCase().includes(q) ||
      r.paymentMethod.toLowerCase().includes(q) ||
      r.date.includes(q) ||
      r.price.toString().includes(q)
    );
  });

  const sorted = [...filtered].sort((a, b) => {
    const valA = a[sortField];
    const valB = b[sortField];
    const modifier = sortDirection === 'asc' ? 1 : -1;

    if (typeof valA === 'number' && typeof valB === 'number') {
      return (valA - valB) * modifier;
    }
    return String(valA).localeCompare(String(valB)) * modifier;
  });

  // Pagination
  const totalPages = Math.ceil(sorted.length / pageSize) || 1;
  const paginated = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const startEdit = (r: SalesRecord) => {
    setEditingId(r.id);
    setEditForm(r);
  };

  const saveEdit = () => {
    if (editingId && editForm.orderNumber && editForm.product && editForm.price !== undefined && editForm.date && editForm.paymentMethod) {
      onUpdateRecord(editForm as SalesRecord);
      setEditingId(null);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newRow.orderNumber && newRow.product && newRow.date) {
      onAddRecord(newRow);
      setIsAddOpen(false);
    }
  };

  const handleExportTableCSV = () => {
    const csvContent = exportToCSV(sorted);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `sales_table_filtered_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
      
      {/* Top Action Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-400" />
            Data Explorer & Record Editor
          </h3>
          <p className="text-xs text-slate-400">
            Search, sort, edit inline, or add new records ({sorted.length} records found)
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsAddOpen(!isAddOpen)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl transition-all shadow-md backdrop-blur-md"
          >
            <Plus className="w-4 h-4" />
            Add New Record
          </button>

          <button
            onClick={handleExportTableCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-medium rounded-xl border border-white/10 transition-all backdrop-blur-md"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            Export Filtered CSV
          </button>
        </div>
      </div>

      {/* Add New Record Form Collapse */}
      {isAddOpen && (
        <form onSubmit={handleAddSubmit} className="bg-slate-900/90 border border-indigo-500/40 rounded-2xl p-4 space-y-3 backdrop-blur-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider">Add New Sales Entry</h4>
            <button type="button" onClick={() => setIsAddOpen(false)} className="text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs">
            <div>
              <label className="text-slate-400 font-medium block mb-1">Order Number</label>
              <input
                type="text"
                required
                value={newRow.orderNumber}
                onChange={e => setNewRow(p => ({ ...p, orderNumber: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100 backdrop-blur-md focus:border-indigo-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-400 font-medium block mb-1">Product</label>
              <input
                type="text"
                required
                value={newRow.product}
                onChange={e => setNewRow(p => ({ ...p, product: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100 backdrop-blur-md focus:border-indigo-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-400 font-medium block mb-1">Price ($)</label>
              <input
                type="number"
                step="0.01"
                required
                value={newRow.price}
                onChange={e => setNewRow(p => ({ ...p, price: parseFloat(e.target.value) || 0 }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100 backdrop-blur-md focus:border-indigo-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-400 font-medium block mb-1">Date</label>
              <input
                type="date"
                required
                value={newRow.date}
                onChange={e => setNewRow(p => ({ ...p, date: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100 backdrop-blur-md focus:border-indigo-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-400 font-medium block mb-1">Payment Method</label>
              <select
                value={newRow.paymentMethod}
                onChange={e => setNewRow(p => ({ ...p, paymentMethod: e.target.value }))}
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100 focus:border-indigo-400 focus:outline-none"
              >
                <option value="Credit Card">Credit Card</option>
                <option value="eWallet">eWallet</option>
                <option value="Cash">Cash</option>
                <option value="Debit Card">Debit Card</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all"
            >
              Save Record
            </button>
          </div>
        </form>
      )}

      {/* Table Controls: Search & Page Size */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-indigo-400" />
          <input
            type="text"
            placeholder="Search table contents..."
            value={searchTerm}
            onChange={e => { setSearchTerm(e.target.value); setCurrentPage(1); }}
            className="w-full pl-9 pr-3 py-1.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-400 backdrop-blur-md"
          />
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span>Rows per page:</span>
          <select
            value={pageSize}
            onChange={e => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
            className="bg-slate-900/90 border border-white/10 rounded-xl px-2 py-1 text-slate-200 focus:outline-none"
          >
            <option value={15}>15</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
      </div>

      {/* Data Table */}
      <div className="overflow-x-auto rounded-xl border border-white/10">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-white/5 text-slate-400 font-semibold uppercase tracking-wider text-[11px] border-b border-white/10 backdrop-blur-md">
              <th onClick={() => handleSort('orderNumber')} className="py-3 px-3 cursor-pointer hover:text-slate-200">
                <div className="flex items-center gap-1">Order # <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th onClick={() => handleSort('product')} className="py-3 px-3 cursor-pointer hover:text-slate-200">
                <div className="flex items-center gap-1">Product <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th onClick={() => handleSort('price')} className="py-3 px-3 cursor-pointer hover:text-slate-200 text-right">
                <div className="flex items-center justify-end gap-1">Price <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th onClick={() => handleSort('date')} className="py-3 px-3 cursor-pointer hover:text-slate-200 text-center">
                <div className="flex items-center justify-center gap-1">Date <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th onClick={() => handleSort('paymentMethod')} className="py-3 px-3 cursor-pointer hover:text-slate-200">
                <div className="flex items-center gap-1">Payment Method <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th className="py-3 px-3 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10 text-slate-300">
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-500">
                  No records matching search query.
                </td>
              </tr>
            ) : (
              paginated.map((r) => {
                const isEditing = editingId === r.id;

                if (isEditing) {
                  return (
                    <tr key={r.id} className="bg-indigo-950/60 backdrop-blur-md">
                      <td className="py-2 px-2">
                        <input
                          type="text"
                          value={editForm.orderNumber || ''}
                          onChange={e => setEditForm(p => ({ ...p, orderNumber: e.target.value }))}
                          className="w-full bg-slate-900 border border-white/10 rounded px-2 py-1 text-slate-100 text-xs"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <input
                          type="text"
                          value={editForm.product || ''}
                          onChange={e => setEditForm(p => ({ ...p, product: e.target.value }))}
                          className="w-full bg-slate-900 border border-white/10 rounded px-2 py-1 text-slate-100 text-xs"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          step="0.01"
                          value={editForm.price ?? 0}
                          onChange={e => setEditForm(p => ({ ...p, price: parseFloat(e.target.value) || 0 }))}
                          className="w-full bg-slate-900 border border-white/10 rounded px-2 py-1 text-slate-100 text-xs text-right"
                        />
                      </td>
                      <td className="py-2 px-2 text-center">
                        <input
                          type="date"
                          value={editForm.date || ''}
                          onChange={e => setEditForm(p => ({ ...p, date: e.target.value }))}
                          className="bg-slate-900 border border-white/10 rounded px-2 py-1 text-slate-100 text-xs"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <select
                          value={editForm.paymentMethod || ''}
                          onChange={e => setEditForm(p => ({ ...p, paymentMethod: e.target.value }))}
                          className="w-full bg-slate-900 border border-white/10 rounded px-2 py-1 text-slate-100 text-xs"
                        >
                          <option value="Credit Card">Credit Card</option>
                          <option value="eWallet">eWallet</option>
                          <option value="Cash">Cash</option>
                          <option value="Debit Card">Debit Card</option>
                        </select>
                      </td>
                      <td className="py-2 px-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={saveEdit} className="p-1 text-emerald-400 hover:bg-emerald-500/20 rounded">
                            <Check className="w-4 h-4" />
                          </button>
                          <button onClick={() => setEditingId(null)} className="p-1 text-rose-400 hover:bg-rose-500/20 rounded">
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                }

                return (
                  <tr key={r.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-2.5 px-3 font-mono text-indigo-400 font-medium">{r.orderNumber}</td>
                    <td className="py-2.5 px-3 font-semibold text-white">{r.product}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-400">${r.price.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400 font-mono">{r.date}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 text-[11px] rounded-full bg-white/5 border border-white/10 text-slate-300 font-medium backdrop-blur-md">
                        {r.paymentMethod}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => startEdit(r)}
                          className="p-1 text-slate-400 hover:text-indigo-400 hover:bg-white/10 rounded-lg transition-colors"
                          title="Edit Row"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteRecord(r.id)}
                          className="p-1 text-slate-400 hover:text-rose-400 hover:bg-white/10 rounded-lg transition-colors"
                          title="Delete Row"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400 pt-2">
        <div>
          Showing {sorted.length === 0 ? 0 : (currentPage - 1) * pageSize + 1} to{' '}
          {Math.min(currentPage * pageSize, sorted.length)} of {sorted.length} entries
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
            className="p-1.5 bg-white/5 border border-white/10 rounded-xl disabled:opacity-40 hover:bg-white/10 text-slate-200 transition-all backdrop-blur-md"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span>
            Page <strong className="text-slate-200">{currentPage}</strong> of <strong className="text-slate-200">{totalPages}</strong>
          </span>
          <button
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
            className="p-1.5 bg-white/5 border border-white/10 rounded-xl disabled:opacity-40 hover:bg-white/10 text-slate-200 transition-all backdrop-blur-md"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

    </div>
  );
};
