import React, { useState } from 'react';
import { SalesRecord, CustomChartConfig } from '../types';
import { computeCustomChartData } from '../utils/analytics';
import { BarChart2, Settings, Download, RefreshCw, Eye, Sliders } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
  CartesianGrid,
  Cell,
} from 'recharts';

interface CustomChartBuilderProps {
  records: SalesRecord[];
}

const PALETTES = [
  '#6366f1', '#10b981', '#f59e0b', '#f43f5e', '#8b5cf6',
  '#06b6d4', '#ec4899', '#3b82f6', '#14b8a6', '#a855f7'
];

export const CustomChartBuilder: React.FC<CustomChartBuilderProps> = ({ records }) => {
  const [config, setConfig] = useState<CustomChartConfig>({
    xAxis: 'product',
    yAxis: 'revenue',
    chartType: 'bar',
    aggregation: 'sum',
    sortBy: 'val-desc',
  });

  const [showGrid, setShowGrid] = useState(true);

  const chartData = computeCustomChartData(records, config);

  const getYAxisLabel = () => {
    switch (config.yAxis) {
      case 'revenue': return 'Total Revenue ($)';
      case 'units': return 'Units Sold';
      case 'orders': return 'Unique Orders';
      case 'avgPrice': return 'Average Item Price ($)';
      default: return 'Value';
    }
  };

  const getXAxisLabel = () => {
    switch (config.xAxis) {
      case 'product': return 'Product Name';
      case 'paymentMethod': return 'Payment Method';
      case 'date': return 'Transaction Date';
      case 'dayOfWeek': return 'Day of Week';
      case 'priceBucket': return 'Price Bucket';
      default: return 'Category';
    }
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Control Panel Bar */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-indigo-400" />
              Interactive Custom Chart Builder
            </h3>
            <p className="text-xs text-slate-400">
              Customize variables, chart styles, metrics, and aggregations to explore data your way
            </p>
          </div>

          <button
            onClick={() => setConfig({ xAxis: 'product', yAxis: 'revenue', chartType: 'bar', aggregation: 'sum', sortBy: 'val-desc' })}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-white/5 hover:bg-white/10 text-slate-200 text-xs rounded-xl border border-white/10 transition-all backdrop-blur-md"
          >
            <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
            Reset Config
          </button>
        </div>

        {/* Configuration Selectors */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          
          {/* X-Axis Selector */}
          <div className="space-y-1">
            <label className="font-semibold text-slate-400">X-Axis Variable</label>
            <select
              value={config.xAxis}
              onChange={e => setConfig(prev => ({ ...prev, xAxis: e.target.value as any }))}
              className="w-full bg-slate-900/90 border border-white/10 text-slate-100 rounded-xl px-3 py-2 focus:outline-none focus:border-indigo-400 backdrop-blur-md"
            >
              <option value="product">Product Name</option>
              <option value="paymentMethod">Payment Method</option>
              <option value="date">Transaction Date</option>
              <option value="dayOfWeek">Day of Week</option>
              <option value="priceBucket">Price Tier / Bucket</option>
            </select>
          </div>

          {/* Y-Axis Metric */}
          <div className="space-y-1">
            <label className="font-semibold text-slate-400">Y-Axis Metric</label>
            <select
              value={config.yAxis}
              onChange={e => setConfig(prev => ({ ...prev, yAxis: e.target.value as any }))}
              className="w-full bg-slate-900/90 border border-white/10 text-slate-100 rounded-xl px-3 py-2 focus:outline-none focus:border-indigo-400 backdrop-blur-md"
            >
              <option value="revenue">Total Revenue ($)</option>
              <option value="units">Units Sold (Quantity)</option>
              <option value="orders">Unique Orders Count</option>
              <option value="avgPrice">Average Unit Price ($)</option>
            </select>
          </div>

          {/* Chart Type */}
          <div className="space-y-1">
            <label className="font-semibold text-slate-400">Visualization Type</label>
            <select
              value={config.chartType}
              onChange={e => setConfig(prev => ({ ...prev, chartType: e.target.value as any }))}
              className="w-full bg-slate-900/90 border border-white/10 text-slate-100 rounded-xl px-3 py-2 focus:outline-none focus:border-indigo-400 backdrop-blur-md"
            >
              <option value="bar">Bar Chart</option>
              <option value="line">Line Chart</option>
              <option value="area">Area Chart</option>
              <option value="pie">Pie / Donut Chart</option>
              <option value="scatter">Scatter Plot</option>
            </select>
          </div>

          {/* Sorting */}
          <div className="space-y-1">
            <label className="font-semibold text-slate-400">Sort Order</label>
            <select
              value={config.sortBy}
              onChange={e => setConfig(prev => ({ ...prev, sortBy: e.target.value as any }))}
              className="w-full bg-slate-900/90 border border-white/10 text-slate-100 rounded-xl px-3 py-2 focus:outline-none focus:border-indigo-400 backdrop-blur-md"
            >
              <option value="val-desc">Highest Value First</option>
              <option value="val-asc">Lowest Value First</option>
              <option value="key-asc">Category A-Z</option>
              <option value="key-desc">Category Z-A</option>
            </select>
          </div>

          {/* Grid Toggle */}
          <div className="space-y-1 flex flex-col justify-end">
            <button
              onClick={() => setShowGrid(!showGrid)}
              className={`w-full py-2 px-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 transition-all backdrop-blur-md ${
                showGrid
                  ? 'bg-indigo-600/30 border-indigo-400 text-indigo-200'
                  : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              {showGrid ? 'Grid: Visible' : 'Grid: Hidden'}
            </button>
          </div>

        </div>
      </div>

      {/* 2. Rendered Custom Chart Stage */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <h4 className="text-sm font-bold text-slate-200">
            {getYAxisLabel()} by {getXAxisLabel()}
          </h4>
          <span className="text-xs text-slate-400 font-mono">
            {chartData.length} data points
          </span>
        </div>

        <div className="h-96 w-full">
          {chartData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-500 text-xs">
              No data matches chart specifications.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              {config.chartType === 'bar' ? (
                <BarChart data={chartData} margin={{ top: 20, right: 20, left: 10, bottom: 40 }}>
                  {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />}
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} angle={-25} textAnchor="end" interval={0} />
                  <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={v => (config.yAxis === 'revenue' || config.yAxis === 'avgPrice' ? `$${v}` : v)} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(255, 255, 255, 0.15)', borderRadius: '16px', color: '#fff', fontSize: '12px', backdropFilter: 'blur(12px)' }}
                    formatter={(val: any) => [config.yAxis === 'revenue' || config.yAxis === 'avgPrice' ? `$${Number(val).toLocaleString()}` : val, getYAxisLabel()]}
                  />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={28}>
                    {chartData.map((_, idx) => (
                      <Cell key={idx} fill={PALETTES[idx % PALETTES.length]} />
                    ))}
                  </Bar>
                </BarChart>
              ) : config.chartType === 'line' ? (
                <LineChart data={chartData} margin={{ top: 20, right: 20, left: 10, bottom: 40 }}>
                  {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />}
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} angle={-25} textAnchor="end" />
                  <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={v => (config.yAxis === 'revenue' || config.yAxis === 'avgPrice' ? `$${v}` : v)} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(255, 255, 255, 0.15)', borderRadius: '16px', color: '#fff', fontSize: '12px', backdropFilter: 'blur(12px)' }}
                    formatter={(val: any) => [config.yAxis === 'revenue' || config.yAxis === 'avgPrice' ? `$${Number(val).toLocaleString()}` : val, getYAxisLabel()]}
                  />
                  <Line type="monotone" dataKey="value" stroke="#6366f1" strokeWidth={3} dot={{ fill: '#6366f1', r: 5 }} />
                </LineChart>
              ) : config.chartType === 'area' ? (
                <AreaChart data={chartData} margin={{ top: 20, right: 20, left: 10, bottom: 40 }}>
                  {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />}
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} angle={-25} textAnchor="end" />
                  <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={v => (config.yAxis === 'revenue' || config.yAxis === 'avgPrice' ? `$${v}` : v)} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(255, 255, 255, 0.15)', borderRadius: '16px', color: '#fff', fontSize: '12px', backdropFilter: 'blur(12px)' }}
                    formatter={(val: any) => [config.yAxis === 'revenue' || config.yAxis === 'avgPrice' ? `$${Number(val).toLocaleString()}` : val, getYAxisLabel()]}
                  />
                  <Area type="monotone" dataKey="value" stroke="#10b981" fill="#10b981" fillOpacity={0.3} strokeWidth={2.5} />
                </AreaChart>
              ) : config.chartType === 'pie' ? (
                <PieChart>
                  <Pie
                    data={chartData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={120}
                    innerRadius={50}
                    paddingAngle={3}
                  >
                    {chartData.map((_, idx) => (
                      <Cell key={idx} fill={PALETTES[idx % PALETTES.length]} stroke="#0f172a" strokeWidth={2} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(255, 255, 255, 0.15)', borderRadius: '16px', color: '#fff', fontSize: '12px', backdropFilter: 'blur(12px)' }}
                    formatter={(val: any) => [config.yAxis === 'revenue' || config.yAxis === 'avgPrice' ? `$${Number(val).toLocaleString()}` : val, getYAxisLabel()]}
                  />
                </PieChart>
              ) : (
                <ScatterChart margin={{ top: 20, right: 20, left: 10, bottom: 40 }}>
                  {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />}
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                  <YAxis dataKey="value" stroke="#94a3b8" fontSize={11} />
                  <ZAxis type="number" dataKey="revenue" range={[100, 500]} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(255, 255, 255, 0.15)', borderRadius: '16px', color: '#fff', fontSize: '12px', backdropFilter: 'blur(12px)' }}
                  />
                  <Scatter data={chartData} fill="#8b5cf6" />
                </ScatterChart>
              )}
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* 3. Generated Aggregated Data Summary Table */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-3">
        <h4 className="text-sm font-bold text-white">Aggregated Data Summary Table</h4>
        <div className="overflow-x-auto max-h-60 overflow-y-auto custom-scrollbar">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-semibold uppercase text-[11px]">
                <th className="py-2 px-3">{getXAxisLabel()}</th>
                <th className="py-2 px-3 text-right">{getYAxisLabel()}</th>
                <th className="py-2 px-3 text-right">Revenue ($)</th>
                <th className="py-2 px-3 text-right">Units Sold</th>
                <th className="py-2 px-3 text-right">Orders</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10 text-slate-300">
              {chartData.map((row, idx) => (
                <tr key={idx} className="hover:bg-white/5">
                  <td className="py-2.5 px-3 font-semibold text-white">{row.name}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-indigo-400">{row.value.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-emerald-400">${row.revenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right">{row.units}</td>
                  <td className="py-2.5 px-3 text-right">{row.orders}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
