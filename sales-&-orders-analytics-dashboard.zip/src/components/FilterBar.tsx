import React, { useState } from 'react';
import { Search, Calendar, Filter, X, ChevronDown, Check, DollarSign, Package, CreditCard, ShoppingBag } from 'lucide-react';
import { FilterState } from '../types';

interface FilterBarProps {
  filter: FilterState;
  setFilter: React.Dispatch<React.SetStateAction<FilterState>>;
  allProducts: string[];
  allPaymentMethods: string[];
  onResetFilters: () => void;
  hasActiveFilters: boolean;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filter,
  setFilter,
  allProducts,
  allPaymentMethods,
  onResetFilters,
  hasActiveFilters,
}) => {
  const [isProductDropdownOpen, setIsProductDropdownOpen] = useState(false);
  const [productSearch, setProductSearch] = useState('');

  // Date range presets
  const applyDatePreset = (preset: 'all' | 'aug' | 'sep' | 'oct') => {
    if (preset === 'all') {
      setFilter(prev => ({ ...prev, startDate: '', endDate: '' }));
    } else if (preset === 'aug') {
      setFilter(prev => ({ ...prev, startDate: '2025-08-01', endDate: '2025-08-31' }));
    } else if (preset === 'sep') {
      setFilter(prev => ({ ...prev, startDate: '2025-09-01', endDate: '2025-09-30' }));
    } else if (preset === 'oct') {
      setFilter(prev => ({ ...prev, startDate: '2025-10-01', endDate: '2025-10-31' }));
    }
  };

  const togglePaymentMethod = (method: string) => {
    setFilter(prev => {
      const exists = prev.paymentMethods.includes(method);
      const newMethods = exists
        ? prev.paymentMethods.filter(m => m !== method)
        : [...prev.paymentMethods, method];
      return { ...prev, paymentMethods: newMethods };
    });
  };

  const toggleProduct = (prod: string) => {
    setFilter(prev => {
      const exists = prev.products.includes(prod);
      const newProds = exists
        ? prev.products.filter(p => p !== prod)
        : [...prev.products, prod];
      return { ...prev, products: newProds };
    });
  };

  const filteredProductsList = allProducts.filter(p =>
    p.toLowerCase().includes(productSearch.toLowerCase())
  );

  return (
    <div className="bg-white/[0.03] backdrop-blur-xl border-b border-white/10 text-slate-200 py-3.5 px-4 sm:px-6 lg:px-8 relative z-30">
      <div className="max-w-7xl mx-auto space-y-3.5">
        {/* Main Controls Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-3.5 items-center">
          
          {/* 1. Global Search Box */}
          <div className="lg:col-span-3 md:col-span-1 col-span-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4 text-indigo-400" />
            </div>
            <input
              type="text"
              placeholder="Search product, order #, payment..."
              value={filter.searchQuery}
              onChange={e => setFilter(prev => ({ ...prev, searchQuery: e.target.value }))}
              className="w-full pl-9 pr-8 py-2 text-xs bg-white/5 border border-white/10 rounded-xl text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-400 focus:bg-white/10 focus:ring-1 focus:ring-indigo-400 transition-all backdrop-blur-md"
            />
            {filter.searchQuery && (
              <button
                onClick={() => setFilter(prev => ({ ...prev, searchQuery: '' }))}
                className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* 2. Date Range Presets & Inputs */}
          <div className="lg:col-span-5 md:col-span-1 col-span-1 flex items-center gap-2 flex-wrap xl:flex-nowrap">
            <div className="flex items-center bg-white/5 p-1 rounded-xl border border-white/10 text-xs text-slate-300 backdrop-blur-md shrink-0">
              <button
                onClick={() => applyDatePreset('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                  !filter.startDate && !filter.endDate ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'hover:text-white hover:bg-white/5'
                }`}
              >
                All Time
              </button>
              <button
                onClick={() => applyDatePreset('aug')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                  filter.startDate === '2025-08-01' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'hover:text-white hover:bg-white/5'
                }`}
              >
                Aug
              </button>
              <button
                onClick={() => applyDatePreset('sep')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                  filter.startDate === '2025-09-01' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'hover:text-white hover:bg-white/5'
                }`}
              >
                Sep
              </button>
              <button
                onClick={() => applyDatePreset('oct')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                  filter.startDate === '2025-10-01' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'hover:text-white hover:bg-white/5'
                }`}
              >
                Oct
              </button>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-400 shrink-0">
              <input
                type="date"
                value={filter.startDate}
                onChange={e => setFilter(prev => ({ ...prev, startDate: e.target.value }))}
                className="w-[115px] bg-white/5 border border-white/10 rounded-xl px-2 py-1.5 text-slate-200 text-[11px] font-mono focus:outline-none focus:border-indigo-400 backdrop-blur-md"
              />
              <span>to</span>
              <input
                type="date"
                value={filter.endDate}
                onChange={e => setFilter(prev => ({ ...prev, endDate: e.target.value }))}
                className="w-[115px] bg-white/5 border border-white/10 rounded-xl px-2 py-1.5 text-slate-200 text-[11px] font-mono focus:outline-none focus:border-indigo-400 backdrop-blur-md"
              />
            </div>
          </div>

          {/* 3. Product Multi-select Dropdown */}
          <div className="lg:col-span-2 md:col-span-1 col-span-1 relative z-40">
            <button
              onClick={() => setIsProductDropdownOpen(!isProductDropdownOpen)}
              className="w-full flex items-center justify-between px-3 py-2 text-xs bg-white/5 border border-white/10 rounded-xl text-slate-200 hover:bg-white/10 hover:border-white/20 transition-all backdrop-blur-md min-w-0"
            >
              <span className="flex items-center gap-2 truncate pr-1">
                <ShoppingBag className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span className="truncate">
                  {filter.products.length === 0
                    ? 'All Products'
                    : `${filter.products.length} Product${filter.products.length > 1 ? 's' : ''}`}
                </span>
              </span>
              <ChevronDown className={`w-3.5 h-3.5 text-slate-400 shrink-0 transition-transform ${isProductDropdownOpen ? 'rotate-180 text-indigo-400' : ''}`} />
            </button>

            {isProductDropdownOpen && (
              <>
                {/* Backdrop overlay so clicking outside closes dropdown */}
                <div
                  className="fixed inset-0 z-[90]"
                  onClick={() => setIsProductDropdownOpen(false)}
                />

                {/* Dropdown menu layer floating smoothly above all panels */}
                <div className="absolute top-full left-0 right-0 mt-2 bg-slate-900/95 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-2xl shadow-black/80 z-[100] p-3 text-xs space-y-2 ring-1 ring-white/10">
                  <input
                    type="text"
                    placeholder="Filter product list..."
                    value={productSearch}
                    onChange={e => setProductSearch(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-slate-950/80 border border-white/10 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-400 text-xs"
                  />
                  
                  <div className="flex justify-between items-center text-[11px] text-slate-400 px-1 border-b border-white/10 pb-1.5">
                    <button
                      onClick={() => setFilter(prev => ({ ...prev, products: [] }))}
                      className="hover:text-indigo-400 text-left font-medium"
                    >
                      Select All
                    </button>
                    {filter.products.length > 0 && (
                      <button
                        onClick={() => setFilter(prev => ({ ...prev, products: [] }))}
                        className="text-amber-400 hover:underline"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  <div className="max-h-52 overflow-y-auto space-y-1 pr-1 custom-scrollbar">
                    {filteredProductsList.map(prod => {
                      const isSelected = filter.products.includes(prod);
                      return (
                        <div
                          key={prod}
                          onClick={() => toggleProduct(prod)}
                          className={`flex items-center justify-between px-2.5 py-1.5 rounded-xl cursor-pointer transition-colors ${
                            isSelected ? 'bg-indigo-600/30 text-indigo-200 font-medium border border-indigo-500/30' : 'hover:bg-white/10 text-slate-300'
                          }`}
                        >
                          <span className="truncate pr-2">{prod}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* 4. Order Type Selector */}
          <div className="lg:col-span-2 md:col-span-1 col-span-1 flex items-center justify-end">
            <div className="flex items-center bg-white/5 p-1 rounded-xl border border-white/10 text-xs w-full justify-between backdrop-blur-md">
              <button
                onClick={() => setFilter(prev => ({ ...prev, orderType: 'all' }))}
                className={`px-2 py-1 rounded-lg font-medium flex-1 text-center transition-all ${
                  filter.orderType === 'all' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-400 hover:text-white'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilter(prev => ({ ...prev, orderType: 'single' }))}
                className={`px-2 py-1 rounded-lg font-medium flex-1 text-center transition-all ${
                  filter.orderType === 'single' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-400 hover:text-white'
                }`}
                title="Orders with 1 item"
              >
                Single
              </button>
              <button
                onClick={() => setFilter(prev => ({ ...prev, orderType: 'multi' }))}
                className={`px-2 py-1 rounded-lg font-medium flex-1 text-center transition-all ${
                  filter.orderType === 'multi' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-400 hover:text-white'
                }`}
                title="Orders with 2+ items"
              >
                Multi
              </button>
            </div>
          </div>

        </div>

        {/* Secondary Controls: Payment Methods & Price Filter */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2.5 border-t border-white/10">
          
          {/* Payment Method Pills */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5 mr-1">
              <CreditCard className="w-3.5 h-3.5 text-indigo-400" />
              Payment:
            </span>
            {allPaymentMethods.map(method => {
              const active = filter.paymentMethods.includes(method);
              return (
                <button
                  key={method}
                  onClick={() => togglePaymentMethod(method)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-xl border transition-all ${
                    active
                      ? 'bg-indigo-600 border-indigo-400 text-white shadow-md shadow-indigo-500/20'
                      : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:text-white hover:border-white/20'
                  }`}
                >
                  {method}
                </button>
              );
            })}
          </div>

          {/* Price Filter */}
          <div className="flex items-center gap-2 text-xs text-slate-400 shrink-0">
            <span className="font-semibold text-slate-400 flex items-center gap-1 shrink-0">
              <DollarSign className="w-3.5 h-3.5 text-emerald-400" /> Price Range:
            </span>
            <input
              type="number"
              min="0"
              max="1000"
              value={filter.minPrice || ''}
              onChange={e => setFilter(prev => ({ ...prev, minPrice: Number(e.target.value) || 0 }))}
              placeholder="Min ($)"
              className="w-22 pl-2.5 pr-1.5 py-1.5 text-xs text-slate-100 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-400 backdrop-blur-md [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
            <span>-</span>
            <input
              type="number"
              min="0"
              max="1000"
              value={filter.maxPrice === 1000 ? '' : filter.maxPrice}
              onChange={e => setFilter(prev => ({ ...prev, maxPrice: e.target.value ? Number(e.target.value) : 1000 }))}
              placeholder="Max ($)"
              className="w-22 pl-2.5 pr-1.5 py-1.5 text-xs text-slate-100 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-400 backdrop-blur-md [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>

        </div>

        {/* Active Filter Chips / Pills Display */}
        {hasActiveFilters && (
          <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-white/10 text-xs">
            <span className="text-slate-400 font-medium">Active Filters:</span>

            {filter.searchQuery && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-200 rounded-full backdrop-blur-md">
                Search: "{filter.searchQuery}"
                <X className="w-3 h-3 cursor-pointer hover:text-white" onClick={() => setFilter(p => ({ ...p, searchQuery: '' }))} />
              </span>
            )}

            {(filter.startDate || filter.endDate) && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-200 rounded-full backdrop-blur-md">
                Date: {filter.startDate || 'Start'} to {filter.endDate || 'End'}
                <X className="w-3 h-3 cursor-pointer hover:text-white" onClick={() => setFilter(p => ({ ...p, startDate: '', endDate: '' }))} />
              </span>
            )}

            {filter.paymentMethods.map(m => (
              <span key={m} className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-200 rounded-full backdrop-blur-md">
                {m}
                <X className="w-3 h-3 cursor-pointer hover:text-white" onClick={() => togglePaymentMethod(m)} />
              </span>
            ))}

            {filter.products.map(p => (
              <span key={p} className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-200 rounded-full truncate max-w-xs backdrop-blur-md">
                {p}
                <X className="w-3 h-3 cursor-pointer hover:text-white shrink-0" onClick={() => toggleProduct(p)} />
              </span>
            ))}

            {filter.orderType !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-200 rounded-full capitalize backdrop-blur-md">
                {filter.orderType} Basket
                <X className="w-3 h-3 cursor-pointer hover:text-white" onClick={() => setFilter(p => ({ ...p, orderType: 'all' }))} />
              </span>
            )}

            {(filter.minPrice > 0 || filter.maxPrice < 1000) && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-200 rounded-full backdrop-blur-md">
                Price: ${filter.minPrice} - ${filter.maxPrice}
                <X className="w-3 h-3 cursor-pointer hover:text-white" onClick={() => setFilter(p => ({ ...p, minPrice: 0, maxPrice: 1000 }))} />
              </span>
            )}

            <button
              onClick={onResetFilters}
              className="text-amber-400 hover:text-amber-300 text-xs underline font-medium ml-1"
            >
              Clear All Filters
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
