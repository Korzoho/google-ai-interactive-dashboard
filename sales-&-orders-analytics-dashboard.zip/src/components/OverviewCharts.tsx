import React, { useState } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  BarChart,
} from 'recharts';
import { TimelineDataPoint, ProductPerformance, PaymentPerformance } from '../types';
import { TrendingUp, PieChart as PieIcon, BarChart3, Calendar, Filter } from 'lucide-react';

interface OverviewChartsProps {
  timelineData: TimelineDataPoint[];
  productPerformance: ProductPerformance[];
  paymentPerformance: PaymentPerformance[];
  onFilterByProduct: (productName: string) => void;
  onFilterByPayment: (paymentName: string) => void;
}

const PAYMENT_COLORS: Record<string, string> = {
  'Credit Card': '#6366f1', // Indigo
  'eWallet': '#10b981',    // Emerald
  'Cash': '#f59e0b',       // Amber
  'Debit Card': '#f43f5e',   // Rose
};

const DEFAULT_COLORS = ['#6366f1', '#10b981', '#f59e0b', '#f43f5e', '#8b5cf6', '#06b6d4', '#3b82f6'];

export const OverviewCharts: React.FC<OverviewChartsProps> = ({
  timelineData,
  productPerformance,
  paymentPerformance,
  onFilterByProduct,
  onFilterByPayment,
}) => {
  const [timelineMode, setTimelineMode] = useState<'daily' | 'cumulative'>('daily');

  // Format date for timeline x-axis (MM/DD)
  const formatXDate = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[1]}/${parts[2]}`;
    return dateStr;
  };

  const top8Products = productPerformance.slice(0, 8);

  return (
    <div className="space-y-6">
      
      {/* 1. Main Timeline Chart (Full Width) */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
              Revenue & Order Volume Timeline
            </h3>
            <p className="text-xs text-slate-400">
              Track daily sales trends, unit volume, and cumulative revenue growth
            </p>
          </div>

          <div className="flex items-center bg-white/5 p-1 rounded-xl border border-white/10 text-xs backdrop-blur-md">
            <button
              onClick={() => setTimelineMode('daily')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                timelineMode === 'daily' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Daily Trends
            </button>
            <button
              onClick={() => setTimelineMode('cumulative')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                timelineMode === 'cumulative' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Cumulative Growth
            </button>
          </div>
        </div>

        {/* Recharts Timeline */}
        <div className="h-80 w-full">
          {timelineData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-500 text-xs">
              No timeline data available for current filter selection.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={timelineData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#818cf8" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#818cf8" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="cumGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#34d399" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#34d399" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />
                <XAxis dataKey="date" tickFormatter={formatXDate} stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis
                  yAxisId="left"
                  stroke="#94a3b8"
                  fontSize={11}
                  tickFormatter={v => `$${v}`}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    borderColor: 'rgba(255, 255, 255, 0.15)',
                    borderRadius: '16px',
                    color: '#f8fafc',
                    fontSize: '12px',
                    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.7)',
                    backdropFilter: 'blur(12px)',
                  }}
                  formatter={(value: any, name: string) => {
                    if (name === 'revenue' || name === 'cumRevenue') return [`$${Number(value).toFixed(2)}`, name === 'revenue' ? 'Revenue' : 'Cumulative Rev'];
                    if (name === 'units') return [`${value} items`, 'Items Sold'];
                    if (name === 'orders') return [`${value} orders`, 'Orders'];
                    return [value, name];
                  }}
                  labelFormatter={(lbl) => `Date: ${lbl}`}
                />

                {timelineMode === 'daily' ? (
                  <>
                    <Area
                      yAxisId="left"
                      type="monotone"
                      dataKey="revenue"
                      name="revenue"
                      stroke="#818cf8"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#revenueGrad)"
                    />
                    <Bar
                      yAxisId="right"
                      dataKey="units"
                      name="units"
                      fill="#38bdf8"
                      opacity={0.7}
                      radius={[6, 6, 0, 0]}
                      barSize={12}
                    />
                  </>
                ) : (
                  <Area
                    yAxisId="left"
                    type="monotone"
                    dataKey="cumRevenue"
                    name="cumRevenue"
                    stroke="#34d399"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#cumGrad)"
                  />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* 2. Grid of Payment Donut & Top Products Horizontal Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Payment Methods Distribution (5 cols) */}
        <div className="lg:col-span-5 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-emerald-400" />
              Payment Method Breakdown
            </h3>
            <p className="text-xs text-slate-400">
              Distribution of revenue and volume across payment channels
            </p>
          </div>

          <div className="h-64 w-full relative">
            {paymentPerformance.length === 0 ? (
              <div className="h-full flex items-center justify-center text-slate-500 text-xs">
                No payment data available.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={paymentPerformance}
                    dataKey="revenue"
                    nameKey="method"
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={4}
                    cursor="pointer"
                    onClick={(entry: any) => onFilterByPayment(entry.payload?.method || entry.method || '')}
                  >
                    {paymentPerformance.map((entry) => (
                      <Cell
                        key={entry.method}
                        fill={PAYMENT_COLORS[entry.method] || '#6366f1'}
                        stroke="#0f172a"
                        strokeWidth={2}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.95)',
                      borderColor: 'rgba(255, 255, 255, 0.15)',
                      borderRadius: '16px',
                      color: '#f8fafc',
                      fontSize: '12px',
                      backdropFilter: 'blur(12px)',
                    }}
                    formatter={(val: any, name: string, props: any) => [
                      `$${Number(val).toLocaleString()} (${props.payload.percentage}%)`,
                      props.payload.method,
                    ]}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Payment Method Legend & Quick Filter Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
            {paymentPerformance.map((p) => {
              const color = PAYMENT_COLORS[p.method] || '#6366f1';
              return (
                <div
                  key={p.method}
                  onClick={() => onFilterByPayment(p.method)}
                  className="flex items-center justify-between p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 cursor-pointer transition-all backdrop-blur-md"
                  title={`Click to filter by ${p.method}`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: color }} />
                    <span className="text-xs font-medium text-slate-200 truncate">{p.method}</span>
                  </div>
                  <span className="text-xs font-bold text-slate-300 ml-1">{p.percentage}%</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top 8 Products Horizontal Bar Chart (7 cols) */}
        <div className="lg:col-span-7 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-amber-400" />
                Top Products by Revenue
              </h3>
              <p className="text-xs text-slate-400">
                Click any bar to instantly filter the dashboard
              </p>
            </div>
            <span className="text-xs text-amber-400 font-medium bg-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded-full backdrop-blur-md">
              Top 8
            </span>
          </div>

          <div className="h-80 w-full">
            {top8Products.length === 0 ? (
              <div className="h-full flex items-center justify-center text-slate-500 text-xs">
                No product performance data available.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  layout="vertical"
                  data={top8Products}
                  margin={{ top: 0, right: 20, left: 20, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} horizontal={false} />
                  <XAxis type="number" stroke="#94a3b8" fontSize={11} tickFormatter={v => `$${v}`} tickLine={false} />
                  <YAxis
                    type="category"
                    dataKey="product"
                    stroke="#cbd5e1"
                    fontSize={11}
                    width={140}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.95)',
                      borderColor: 'rgba(255, 255, 255, 0.15)',
                      borderRadius: '16px',
                      color: '#f8fafc',
                      fontSize: '12px',
                      backdropFilter: 'blur(12px)',
                    }}
                    formatter={(val: any, name: string, props: any) => [
                      `$${Number(val).toLocaleString()} (${props.payload.unitsSold} units)`,
                      'Revenue',
                    ]}
                  />
                  <Bar
                    dataKey="revenue"
                    radius={[0, 8, 8, 0]}
                    cursor="pointer"
                    onClick={(entry: any) => onFilterByProduct(entry.payload?.product || entry.product || '')}
                  >
                    {top8Products.map((_, idx) => (
                      <Cell
                        key={`cell-${idx}`}
                        fill={DEFAULT_COLORS[idx % DEFAULT_COLORS.length]}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Product Color Code Key & Legend */}
          <div className="space-y-2 pt-3 border-t border-white/10">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-300/90 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                Product Color Key & Quick Filter
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {top8Products.length} Items Listed
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {top8Products.map((p, idx) => {
                const colorHex = DEFAULT_COLORS[idx % DEFAULT_COLORS.length];
                return (
                  <div
                    key={p.product}
                    onClick={() => onFilterByProduct(p.product)}
                    className="flex flex-col justify-between p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 cursor-pointer transition-all backdrop-blur-md group hover:border-amber-400/30"
                    title={`Click to filter dashboard by ${p.product}`}
                  >
                    <div className="flex items-center gap-2 min-w-0 mb-1">
                      <span
                        className="w-3 h-3 rounded-full shrink-0 shadow-sm group-hover:scale-125 transition-transform border border-white/20"
                        style={{ backgroundColor: colorHex }}
                      />
                      <span className="text-xs font-semibold text-slate-100 truncate group-hover:text-amber-300 transition-colors">
                        {p.product}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] font-mono border-t border-white/5 pt-1 mt-1 text-slate-400">
                      <span className="text-slate-400 font-semibold">{colorHex}</span>
                      <span className="font-bold text-amber-300">${Math.round(p.revenue).toLocaleString()}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
