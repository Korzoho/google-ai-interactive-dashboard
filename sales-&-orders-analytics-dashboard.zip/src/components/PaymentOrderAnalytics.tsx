import React from 'react';
import { PaymentPerformance, TimelineDataPoint, BasketSizeDistribution } from '../types';
import { CreditCard, ShoppingBag, Calendar, DollarSign, Layers } from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  Cell,
} from 'recharts';

interface PaymentOrderAnalyticsProps {
  payments: PaymentPerformance[];
  timelineData: TimelineDataPoint[];
  basketData: { basketDistribution: BasketSizeDistribution[]; totalOrders: number };
  dayOfWeekData: { day: string; revenue: number; items: number; orders: number }[];
  onFilterByPayment: (paymentName: string) => void;
}

const PAYMENT_COLORS: Record<string, string> = {
  'Credit Card': '#6366f1',
  'eWallet': '#10b981',
  'Cash': '#f59e0b',
  'Debit Card': '#f43f5e',
};

export const PaymentOrderAnalytics: React.FC<PaymentOrderAnalyticsProps> = ({
  payments,
  timelineData,
  basketData,
  dayOfWeekData,
  onFilterByPayment,
}) => {
  return (
    <div className="space-y-6">
      
      {/* 1. Payment Method Trends Over Time (Stacked Area) */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-indigo-400" />
            Payment Channel Revenue Trends Over Time
          </h3>
          <p className="text-xs text-slate-400">
            Daily revenue contribution across Credit Card, eWallet, Cash, and Debit Card
          </p>
        </div>

        <div className="h-72 w-full">
          {timelineData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-500 text-xs">
              No timeline data for current filter.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timelineData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={v => `$${v}`} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    borderColor: 'rgba(255, 255, 255, 0.15)',
                    borderRadius: '16px',
                    color: '#f8fafc',
                    fontSize: '12px',
                    backdropFilter: 'blur(12px)',
                  }}
                  formatter={(val: any, name: string) => [`$${Number(val).toFixed(2)}`, name]}
                />
                <Area type="monotone" dataKey="CreditCard" name="Credit Card" stackId="1" stroke="#6366f1" fill="#6366f1" fillOpacity={0.6} />
                <Area type="monotone" dataKey="eWallet" name="eWallet" stackId="1" stroke="#10b981" fill="#10b981" fillOpacity={0.6} />
                <Area type="monotone" dataKey="Cash" name="Cash" stackId="1" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.6} />
                <Area type="monotone" dataKey="DebitCard" name="Debit Card" stackId="1" stroke="#f43f5e" fill="#f43f5e" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* 2. Basket Size & Day of Week Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Basket Size Breakdown (6 cols) */}
        <div className="lg:col-span-6 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400" />
              Basket Size Distribution
            </h3>
            <p className="text-xs text-slate-400">
              Single-item vs multi-item basket volume & revenue
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {basketData.basketDistribution.map((b) => (
              <div key={b.sizeLabel} className="bg-white/5 border border-white/10 rounded-xl p-3.5 space-y-1 backdrop-blur-md">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{b.sizeLabel}</span>
                <div className="text-xl font-bold text-white">{b.count} <span className="text-xs text-slate-400 font-normal">orders</span></div>
                <div className="text-xs font-semibold text-emerald-400">${b.revenue.toLocaleString()}</div>
                <div className="text-[10px] text-slate-400">{b.percentage}% of total</div>
              </div>
            ))}
          </div>

          {/* Basket Size Bar Chart */}
          <div className="h-44 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={basketData.basketDistribution} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />
                <XAxis dataKey="sizeLabel" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={v => `$${v}`} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(255, 255, 255, 0.15)', borderRadius: '16px', color: '#fff', fontSize: '12px', backdropFilter: 'blur(12px)' }}
                  formatter={(v: any) => [`$${Number(v).toLocaleString()}`, 'Revenue']}
                />
                <Bar dataKey="revenue" fill="#10b981" radius={[6, 6, 0, 0]} barSize={36} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Day of Week Sales Heatmap (6 cols) */}
        <div className="lg:col-span-6 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              Day of Week Sales Matrix
            </h3>
            <p className="text-xs text-slate-400">
              Revenue and items sold distribution from Sunday through Saturday
            </p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dayOfWeekData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.1} />
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={v => `$${v}`} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(255, 255, 255, 0.15)', borderRadius: '16px', color: '#fff', fontSize: '12px', backdropFilter: 'blur(12px)' }}
                  formatter={(v: any, name: string) => [
                    name === 'revenue' ? `$${Number(v).toLocaleString()}` : `${v} items`,
                    name === 'revenue' ? 'Revenue' : 'Items Sold'
                  ]}
                />
                <Bar dataKey="revenue" fill="#6366f1" radius={[6, 6, 0, 0]} barSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* 3. Payment Method Metrics Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {payments.map(p => {
          const color = PAYMENT_COLORS[p.method] || '#6366f1';
          return (
            <div
              key={p.method}
              onClick={() => onFilterByPayment(p.method)}
              className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4 hover:bg-white/10 cursor-pointer transition-all space-y-2 shadow-xl"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                  {p.method}
                </span>
                <span className="text-xs font-bold px-2 py-0.5 bg-white/10 text-slate-200 rounded-full border border-white/10">
                  {p.percentage}%
                </span>
              </div>
              <div className="text-xl font-bold text-white">${p.revenue.toLocaleString()}</div>
              <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-white/10">
                <span>{p.count} transactions</span>
                <span>Avg: <strong>${p.avgTransaction.toFixed(2)}</strong></span>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
