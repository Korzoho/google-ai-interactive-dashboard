import { SalesRecord, FilterState, MetricSummary, ProductPerformance, PaymentPerformance, TimelineDataPoint, CustomChartConfig } from '../types';

export function filterRecords(records: SalesRecord[], filter: FilterState): SalesRecord[] {
  // Pre-calculate order item counts if orderType filtering is active
  let multiItemOrdersMap: Map<string, number> | null = null;
  if (filter.orderType !== 'all') {
    multiItemOrdersMap = new Map();
    for (const r of records) {
      multiItemOrdersMap.set(r.orderNumber, (multiItemOrdersMap.get(r.orderNumber) || 0) + 1);
    }
  }

  const query = filter.searchQuery.trim().toLowerCase();

  return records.filter(record => {
    // Search query check
    if (query) {
      const matchOrder = record.orderNumber.toLowerCase().includes(query);
      const matchProduct = record.product.toLowerCase().includes(query);
      const matchPayment = record.paymentMethod.toLowerCase().includes(query);
      const matchDate = record.date.includes(query);
      const matchPrice = record.price.toString().includes(query);
      if (!matchOrder && !matchProduct && !matchPayment && !matchDate && !matchPrice) {
        return false;
      }
    }

    // Date range check
    if (filter.startDate && record.date < filter.startDate) return false;
    if (filter.endDate && record.date > filter.endDate) return false;

    // Payment methods check
    if (filter.paymentMethods.length > 0 && !filter.paymentMethods.includes(record.paymentMethod)) {
      return false;
    }

    // Products check
    if (filter.products.length > 0 && !filter.products.includes(record.product)) {
      return false;
    }

    // Price range check
    if (record.price < filter.minPrice || record.price > filter.maxPrice) {
      return false;
    }

    // Single vs Multi item order check
    if (filter.orderType !== 'all' && multiItemOrdersMap) {
      const itemCount = multiItemOrdersMap.get(record.orderNumber) || 1;
      if (filter.orderType === 'single' && itemCount > 1) return false;
      if (filter.orderType === 'multi' && itemCount <= 1) return false;
    }

    return true;
  });
}

export function getUniqueProducts(records: SalesRecord[]): string[] {
  const set = new Set<string>();
  records.forEach(r => set.add(r.product));
  return Array.from(set).sort();
}

export function getUniquePaymentMethods(records: SalesRecord[]): string[] {
  const set = new Set<string>();
  records.forEach(r => set.add(r.paymentMethod));
  return Array.from(set).sort();
}

export function computeMetricSummary(records: SalesRecord[]): MetricSummary {
  if (records.length === 0) {
    return {
      totalRevenue: 0,
      totalItemsSold: 0,
      totalUniqueOrders: 0,
      avgOrderValue: 0,
      avgItemPrice: 0,
      topProductByRevenue: { name: 'N/A', revenue: 0, units: 0 },
      topProductByUnits: { name: 'N/A', units: 0, revenue: 0 },
      topPaymentMethod: { name: 'N/A', count: 0, revenue: 0 },
      multiItemOrdersCount: 0,
      multiItemOrdersPercent: 0,
    };
  }

  let totalRevenue = 0;
  const orderTotalMap = new Map<string, number>();
  const orderItemCountMap = new Map<string, number>();
  const productRevMap = new Map<string, number>();
  const productUnitsMap = new Map<string, number>();
  const paymentRevMap = new Map<string, number>();
  const paymentCountMap = new Map<string, number>();

  for (const r of records) {
    totalRevenue += r.price;

    // Order totals
    orderTotalMap.set(r.orderNumber, (orderTotalMap.get(r.orderNumber) || 0) + r.price);
    orderItemCountMap.set(r.orderNumber, (orderItemCountMap.get(r.orderNumber) || 0) + 1);

    // Product map
    productRevMap.set(r.product, (productRevMap.get(r.product) || 0) + r.price);
    productUnitsMap.set(r.product, (productUnitsMap.get(r.product) || 0) + 1);

    // Payment map
    paymentRevMap.set(r.paymentMethod, (paymentRevMap.get(r.paymentMethod) || 0) + r.price);
    paymentCountMap.set(r.paymentMethod, (paymentCountMap.get(r.paymentMethod) || 0) + 1);
  }

  const totalItemsSold = records.length;
  const totalUniqueOrders = orderTotalMap.size;
  const avgOrderValue = totalUniqueOrders > 0 ? totalRevenue / totalUniqueOrders : 0;
  const avgItemPrice = totalItemsSold > 0 ? totalRevenue / totalItemsSold : 0;

  // Top Product by Revenue
  let maxRevProd = 'N/A';
  let maxRevVal = 0;
  productRevMap.forEach((rev, prod) => {
    if (rev > maxRevVal) {
      maxRevVal = rev;
      maxRevProd = prod;
    }
  });

  // Top Product by Units
  let maxUnitsProd = 'N/A';
  let maxUnitsVal = 0;
  productUnitsMap.forEach((units, prod) => {
    if (units > maxUnitsVal) {
      maxUnitsVal = units;
      maxUnitsProd = prod;
    }
  });

  // Top Payment Method
  let topPayMethod = 'N/A';
  let maxPayCount = 0;
  let maxPayRev = 0;
  paymentCountMap.forEach((cnt, pay) => {
    if (cnt > maxPayCount) {
      maxPayCount = cnt;
      topPayMethod = pay;
      maxPayRev = paymentRevMap.get(pay) || 0;
    }
  });

  // Multi-item orders count
  let multiItemOrdersCount = 0;
  orderItemCountMap.forEach((cnt) => {
    if (cnt > 1) multiItemOrdersCount++;
  });
  const multiItemOrdersPercent = totalUniqueOrders > 0 ? (multiItemOrdersCount / totalUniqueOrders) * 100 : 0;

  return {
    totalRevenue,
    totalItemsSold,
    totalUniqueOrders,
    avgOrderValue,
    avgItemPrice,
    topProductByRevenue: { name: maxRevProd, revenue: maxRevVal, units: productUnitsMap.get(maxRevProd) || 0 },
    topProductByUnits: { name: maxUnitsProd, units: maxUnitsVal, revenue: productRevMap.get(maxUnitsProd) || 0 },
    topPaymentMethod: { name: topPayMethod, count: maxPayCount, revenue: maxPayRev },
    multiItemOrdersCount,
    multiItemOrdersPercent,
  };
}

export function computeTimelineData(records: SalesRecord[]): TimelineDataPoint[] {
  if (records.length === 0) return [];

  // Group by date
  const dateMap = new Map<string, {
    revenue: number;
    units: number;
    orders: Set<string>;
    CreditCard: number;
    eWallet: number;
    Cash: number;
    DebitCard: number;
  }>();

  for (const r of records) {
    let entry = dateMap.get(r.date);
    if (!entry) {
      entry = {
        revenue: 0,
        units: 0,
        orders: new Set(),
        CreditCard: 0,
        eWallet: 0,
        Cash: 0,
        DebitCard: 0,
      };
      dateMap.set(r.date, entry);
    }

    entry.revenue += r.price;
    entry.units += 1;
    entry.orders.add(r.orderNumber);

    if (r.paymentMethod === 'Credit Card') entry.CreditCard += r.price;
    else if (r.paymentMethod === 'eWallet') entry.eWallet += r.price;
    else if (r.paymentMethod === 'Cash') entry.Cash += r.price;
    else if (r.paymentMethod === 'Debit Card') entry.DebitCard += r.price;
  }

  const sortedDates = Array.from(dateMap.keys()).sort();

  let cumRev = 0;
  return sortedDates.map(date => {
    const data = dateMap.get(date)!;
    cumRev += data.revenue;
    return {
      date,
      revenue: parseFloat(data.revenue.toFixed(2)),
      units: data.units,
      orders: data.orders.size,
      cumRevenue: parseFloat(cumRev.toFixed(2)),
      CreditCard: parseFloat(data.CreditCard.toFixed(2)),
      eWallet: parseFloat(data.eWallet.toFixed(2)),
      Cash: parseFloat(data.Cash.toFixed(2)),
      DebitCard: parseFloat(data.DebitCard.toFixed(2)),
    };
  });
}

export function computeProductPerformance(records: SalesRecord[]): ProductPerformance[] {
  if (records.length === 0) return [];

  const totalRev = records.reduce((acc, r) => acc + r.price, 0);

  const pMap = new Map<string, {
    revenue: number;
    unitsSold: number;
    prices: number[];
    orders: Set<string>;
    paymentBreakdown: Record<string, number>;
  }>();

  for (const r of records) {
    let entry = pMap.get(r.product);
    if (!entry) {
      entry = {
        revenue: 0,
        unitsSold: 0,
        prices: [],
        orders: new Set(),
        paymentBreakdown: {},
      };
      pMap.set(r.product, entry);
    }

    entry.revenue += r.price;
    entry.unitsSold += 1;
    entry.prices.push(r.price);
    entry.orders.add(r.orderNumber);

    entry.paymentBreakdown[r.paymentMethod] = (entry.paymentBreakdown[r.paymentMethod] || 0) + r.price;
  }

  const result: ProductPerformance[] = [];

  pMap.forEach((entry, prod) => {
    const avgPrice = entry.prices.reduce((a, b) => a + b, 0) / entry.prices.length;
    const revenueSharePercent = totalRev > 0 ? (entry.revenue / totalRev) * 100 : 0;

    result.push({
      product: prod,
      revenue: parseFloat(entry.revenue.toFixed(2)),
      unitsSold: entry.unitsSold,
      avgPrice: parseFloat(avgPrice.toFixed(2)),
      orderCount: entry.orders.size,
      revenueSharePercent: parseFloat(revenueSharePercent.toFixed(1)),
      paymentBreakdown: entry.paymentBreakdown,
    });
  });

  return result.sort((a, b) => b.revenue - a.revenue);
}

export function computePaymentPerformance(records: SalesRecord[]): PaymentPerformance[] {
  if (records.length === 0) return [];

  const totalRev = records.reduce((acc, r) => acc + r.price, 0);

  const payMap = new Map<string, { revenue: number; count: number }>();

  for (const r of records) {
    const entry = payMap.get(r.paymentMethod) || { revenue: 0, count: 0 };
    entry.revenue += r.price;
    entry.count += 1;
    payMap.set(r.paymentMethod, entry);
  }

  const result: PaymentPerformance[] = [];

  payMap.forEach((entry, method) => {
    const percentage = totalRev > 0 ? (entry.revenue / totalRev) * 100 : 0;
    const avgTransaction = entry.count > 0 ? entry.revenue / entry.count : 0;

    result.push({
      method,
      revenue: parseFloat(entry.revenue.toFixed(2)),
      count: entry.count,
      percentage: parseFloat(percentage.toFixed(1)),
      avgTransaction: parseFloat(avgTransaction.toFixed(2)),
    });
  });

  return result.sort((a, b) => b.revenue - a.revenue);
}

export interface BasketSizeDistribution {
  sizeLabel: string;
  count: number;
  revenue: number;
  percentage: number;
}

export interface ProductCoOccurrence {
  productA: string;
  productB: string;
  coOccurrences: number;
}

export function computeBasketAnalysis(records: SalesRecord[]) {
  const orderGroups = new Map<string, SalesRecord[]>();
  for (const r of records) {
    const list = orderGroups.get(r.orderNumber) || [];
    list.push(r);
    orderGroups.set(r.orderNumber, list);
  }

  const totalOrders = orderGroups.size;
  let singleItemCount = 0;
  let singleItemRev = 0;
  let doubleItemCount = 0;
  let doubleItemRev = 0;
  let multiItemCount = 0; // 3+ items
  let multiItemRev = 0;

  const coOccurrenceMap = new Map<string, number>();

  orderGroups.forEach((items) => {
    const size = items.length;
    const orderRev = items.reduce((sum, item) => sum + item.price, 0);

    if (size === 1) {
      singleItemCount++;
      singleItemRev += orderRev;
    } else if (size === 2) {
      doubleItemCount++;
      doubleItemRev += orderRev;
    } else {
      multiItemCount++;
      multiItemRev += orderRev;
    }

    // Calculate product co-occurrences in multi-item orders
    if (size > 1) {
      const uniqueProds = Array.from(new Set(items.map(i => i.product))).sort();
      for (let i = 0; i < uniqueProds.length; i++) {
        for (let j = i + 1; j < uniqueProds.length; j++) {
          const key = `${uniqueProds[i]}|||${uniqueProds[j]}`;
          coOccurrenceMap.set(key, (coOccurrenceMap.get(key) || 0) + 1);
        }
      }
    }
  });

  const basketDistribution: BasketSizeDistribution[] = [
    {
      sizeLabel: '1 Item Order',
      count: singleItemCount,
      revenue: parseFloat(singleItemRev.toFixed(2)),
      percentage: totalOrders > 0 ? parseFloat(((singleItemCount / totalOrders) * 100).toFixed(1)) : 0,
    },
    {
      sizeLabel: '2 Items Order',
      count: doubleItemCount,
      revenue: parseFloat(doubleItemRev.toFixed(2)),
      percentage: totalOrders > 0 ? parseFloat(((doubleItemCount / totalOrders) * 100).toFixed(1)) : 0,
    },
    {
      sizeLabel: '3+ Items Order',
      count: multiItemCount,
      revenue: parseFloat(multiItemRev.toFixed(2)),
      percentage: totalOrders > 0 ? parseFloat(((multiItemCount / totalOrders) * 100).toFixed(1)) : 0,
    },
  ];

  const coOccurrences: ProductCoOccurrence[] = [];
  coOccurrenceMap.forEach((count, key) => {
    const [pA, pB] = key.split('|||');
    coOccurrences.push({ productA: pA, productB: pB, coOccurrences: count });
  });

  coOccurrences.sort((a, b) => b.coOccurrences - a.coOccurrences);

  return { basketDistribution, coOccurrences: coOccurrences.slice(0, 10), totalOrders };
}

export function computeDayOfWeekHeatmap(records: SalesRecord[]) {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayStats = days.map(day => ({ day, revenue: 0, items: 0, orders: new Set<string>() }));

  for (const r of records) {
    const d = new Date(r.date + 'T00:00:00');
    const dayIdx = d.getDay();
    if (!isNaN(dayIdx)) {
      dayStats[dayIdx].revenue += r.price;
      dayStats[dayIdx].items += 1;
      dayStats[dayIdx].orders.add(r.orderNumber);
    }
  }

  return dayStats.map(s => ({
    day: s.day,
    revenue: parseFloat(s.revenue.toFixed(2)),
    items: s.items,
    orders: s.orders.size,
  }));
}

export function computeCustomChartData(records: SalesRecord[], config: CustomChartConfig) {
  const grouped = new Map<string, { revenue: number; units: number; prices: number[]; orders: Set<string> }>();

  const getGroupKey = (r: SalesRecord): string => {
    switch (config.xAxis) {
      case 'product':
        return r.product;
      case 'paymentMethod':
        return r.paymentMethod;
      case 'date':
        return r.date;
      case 'dayOfWeek': {
        const d = new Date(r.date + 'T00:00:00');
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        return days[d.getDay()] || 'Unknown';
      }
      case 'priceBucket': {
        if (r.price < 70) return '< $70';
        if (r.price < 90) return '$70 - $89';
        if (r.price < 120) return '$90 - $119';
        if (r.price < 150) return '$120 - $149';
        return '$150+';
      }
      default:
        return r.product;
    }
  };

  for (const r of records) {
    const key = getGroupKey(r);
    let entry = grouped.get(key);
    if (!entry) {
      entry = { revenue: 0, units: 0, prices: [], orders: new Set() };
      grouped.set(key, entry);
    }
    entry.revenue += r.price;
    entry.units += 1;
    entry.prices.push(r.price);
    entry.orders.add(r.orderNumber);
  }

  let result = Array.from(grouped.entries()).map(([key, data]) => {
    let val = 0;
    if (config.yAxis === 'revenue') {
      val = config.aggregation === 'avg' ? data.revenue / data.units : data.revenue;
    } else if (config.yAxis === 'units') {
      val = data.units;
    } else if (config.yAxis === 'orders') {
      val = data.orders.size;
    } else if (config.yAxis === 'avgPrice') {
      val = data.prices.reduce((a, b) => a + b, 0) / data.prices.length;
    }

    return {
      name: key,
      value: parseFloat(val.toFixed(2)),
      revenue: parseFloat(data.revenue.toFixed(2)),
      units: data.units,
      orders: data.orders.size,
    };
  });

  // Sorting
  if (config.sortBy === 'val-desc') {
    result.sort((a, b) => b.value - a.value);
  } else if (config.sortBy === 'val-asc') {
    result.sort((a, b) => a.value - b.value);
  } else if (config.sortBy === 'key-asc') {
    result.sort((a, b) => a.name.localeCompare(b.name));
  } else if (config.sortBy === 'key-desc') {
    result.sort((a, b) => b.name.localeCompare(a.name));
  }

  return result;
}
