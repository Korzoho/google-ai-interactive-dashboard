import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { SalesRecord } from '../types';

export interface ColumnMapping {
  orderNumberCol: string;
  productCol: string;
  priceCol: string;
  dateCol: string;
  paymentMethodCol: string;
}

export interface ParseResult {
  headers: string[];
  rawRows: Record<string, any>[];
  suggestedMapping: ColumnMapping;
  records: SalesRecord[];
  fileName?: string;
  totalRows: number;
}

/**
 * Smart column auto-detection based on header names
 */
export function detectColumnMapping(headers: string[]): ColumnMapping {
  const normHeaders = headers.map(h => h.trim().toLowerCase());

  const findHeader = (patterns: RegExp[], fallbackIdx: number): string => {
    for (const pattern of patterns) {
      const idx = normHeaders.findIndex(h => pattern.test(h));
      if (idx !== -1) return headers[idx];
    }
    return headers[fallbackIdx] || headers[0] || '';
  };

  const orderNumberCol = findHeader(
    [/order.*num/i, /order.*id/i, /invoice/i, /transaction/i, /^order$/i, /^id$/i, /ref/i, /code/i],
    0
  );

  const productCol = findHeader(
    [/product/i, /item/i, /description/i, /title/i, /name/i, /sku/i, /goods/i, /service/i],
    1 < headers.length ? 1 : 0
  );

  const priceCol = findHeader(
    [/price/i, /amount/i, /revenue/i, /total/i, /cost/i, /val/i, /sales/i, /subtotal/i],
    2 < headers.length ? 2 : 0
  );

  const dateCol = findHeader(
    [/date/i, /time/i, /created/i, /timestamp/i, /day/i, /period/i, /month/i],
    3 < headers.length ? 3 : 0
  );

  const paymentMethodCol = findHeader(
    [/payment/i, /method/i, /type/i, /channel/i, /gateway/i, /category/i, /status/i],
    4 < headers.length ? 4 : 0
  );

  return {
    orderNumberCol,
    productCol,
    priceCol,
    dateCol,
    paymentMethodCol,
  };
}

/**
 * Format date values safely to YYYY-MM-DD
 */
export function formatDateValue(val: any): string {
  if (!val) return new Date().toISOString().slice(0, 10);

  if (val instanceof Date) {
    if (isNaN(val.getTime())) return new Date().toISOString().slice(0, 10);
    return val.toISOString().slice(0, 10);
  }

  if (typeof val === 'number') {
    // Excel serial date conversion
    const dateObj = new Date(Math.round((val - 25569) * 86400 * 1000));
    if (!isNaN(dateObj.getTime())) {
      return dateObj.toISOString().slice(0, 10);
    }
  }

  const str = String(val).trim();
  // Try direct YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}/.test(str)) {
    return str.slice(0, 10);
  }

  // Parse common date formats
  const parsed = new Date(str);
  if (!isNaN(parsed.getTime())) {
    return parsed.toISOString().slice(0, 10);
  }

  return new Date().toISOString().slice(0, 10);
}

/**
 * Parse raw price strings to float
 */
export function parsePriceValue(val: any): number {
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  if (!val) return 0;
  const str = String(val).replace(/[^0-9.-]/g, '');
  const num = parseFloat(str);
  return isNaN(num) ? 0 : num;
}

/**
 * Converts raw JSON objects from sheet/CSV into normalized SalesRecord[] based on mapping
 */
export function convertRowsToSalesRecords(
  rawRows: Record<string, any>[],
  mapping: ColumnMapping
): SalesRecord[] {
  return rawRows.map((row, index) => {
    const rawOrder = row[mapping.orderNumberCol];
    const rawProduct = row[mapping.productCol];
    const rawPrice = row[mapping.priceCol];
    const rawDate = row[mapping.dateCol];
    const rawPayment = row[mapping.paymentMethodCol];

    const orderNumber = rawOrder !== undefined && rawOrder !== null && String(rawOrder).trim() !== ''
      ? String(rawOrder).trim()
      : `ORD-${1000 + index}`;

    const product = rawProduct !== undefined && rawProduct !== null && String(rawProduct).trim() !== ''
      ? String(rawProduct).trim()
      : 'Unspecified Item';

    const price = parsePriceValue(rawPrice);
    const date = formatDateValue(rawDate);
    const paymentMethod = rawPayment !== undefined && rawPayment !== null && String(rawPayment).trim() !== ''
      ? String(rawPayment).trim()
      : 'Standard';

    return {
      id: `rec_import_${index}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      orderNumber,
      product,
      price,
      date,
      paymentMethod,
    };
  });
}

/**
 * Read File object (.csv, .xlsx, .xls, .tsv, .txt) and parse into structured data
 */
export async function parseSpreadsheetFile(file: File): Promise<ParseResult> {
  const fileExt = file.name.split('.').pop()?.toLowerCase();

  // Handle CSV/TSV natively via PapaParse or XLSX
  if (fileExt === 'csv' || fileExt === 'tsv' || fileExt === 'txt') {
    const text = await file.text();
    return parseSpreadsheetText(text, file.name);
  }

  // Handle Excel spreadsheets (.xlsx, .xls) via SheetJS
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
  const firstSheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[firstSheetName];

  const rawRows = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

  let headers: string[] = [];
  if (rawRows.length > 0) {
    headers = Object.keys(rawRows[0]);
  }

  const suggestedMapping = detectColumnMapping(headers);
  const records = convertRowsToSalesRecords(rawRows, suggestedMapping);

  return {
    headers,
    rawRows,
    suggestedMapping,
    records,
    fileName: file.name,
    totalRows: rawRows.length,
  };
}

/**
 * Parse raw text (CSV, TSV) string
 */
export function parseSpreadsheetText(text: string, fileName?: string): ParseResult {
  const result = Papa.parse<Record<string, any>>(text, {
    header: true,
    skipEmptyLines: true,
    dynamicTyping: true,
  });

  const rawRows = result.data || [];
  const headers = result.meta.fields || (rawRows.length > 0 ? Object.keys(rawRows[0]) : []);

  const suggestedMapping = detectColumnMapping(headers);
  const records = convertRowsToSalesRecords(rawRows, suggestedMapping);

  return {
    headers,
    rawRows,
    suggestedMapping,
    records,
    fileName: fileName || 'Uploaded Data',
    totalRows: rawRows.length,
  };
}
