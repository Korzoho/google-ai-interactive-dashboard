import React, { useState, useMemo } from 'react';
import { SalesRecord, FilterState, DashboardView } from './types';
import { INITIAL_SALES_RECORDS } from './data/initialData';
import {
  filterRecords,
  getUniqueProducts,
  getUniquePaymentMethods,
  computeMetricSummary,
  computeTimelineData,
  computeProductPerformance,
  computePaymentPerformance,
  computeBasketAnalysis,
  computeDayOfWeekHeatmap,
} from './utils/analytics';
import { Header } from './components/Header';
import { FilterBar } from './components/FilterBar';
import { KPICards } from './components/KPICards';
import { OverviewCharts } from './components/OverviewCharts';
import { ProductAnalytics } from './components/ProductAnalytics';
import { PaymentOrderAnalytics } from './components/PaymentOrderAnalytics';
import { CustomChartBuilder } from './components/CustomChartBuilder';
import { DataExplorerTable } from './components/DataExplorerTable';
import { ImportDataModal } from './components/ImportDataModal';

const DEFAULT_FILTER: FilterState = {
  searchQuery: '',
  startDate: '',
  endDate: '',
  paymentMethods: [],
  products: [],
  minPrice: 0,
  maxPrice: 1000,
  orderType: 'all',
};

export default function App() {
  const [records, setRecords] = useState<SalesRecord[]>(INITIAL_SALES_RECORDS);
  const [filter, setFilter] = useState<FilterState>(DEFAULT_FILTER);
  const [currentView, setCurrentView] = useState<DashboardView>('overview');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [droppedFile, setDroppedFile] = useState<File | null>(null);

  const handlePageDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handlePageDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      setDroppedFile(e.dataTransfer.files[0]);
      setIsImportModalOpen(true);
    }
  };

  // Derived Datasets
  const allProducts = useMemo(() => getUniqueProducts(records), [records]);
  const allPaymentMethods = useMemo(() => getUniquePaymentMethods(records), [records]);

  const filteredRecords = useMemo(() => filterRecords(records, filter), [records, filter]);

  // Derived Analytics Metrics
  const metricSummary = useMemo(() => computeMetricSummary(filteredRecords), [filteredRecords]);
  const timelineData = useMemo(() => computeTimelineData(filteredRecords), [filteredRecords]);
  const productPerformance = useMemo(() => computeProductPerformance(filteredRecords), [filteredRecords]);
  const paymentPerformance = useMemo(() => computePaymentPerformance(filteredRecords), [filteredRecords]);
  const basketData = useMemo(() => computeBasketAnalysis(filteredRecords), [filteredRecords]);
  const dayOfWeekData = useMemo(() => computeDayOfWeekHeatmap(filteredRecords), [filteredRecords]);

  // Check if filters are active
  const hasActiveFilters = useMemo(() => {
    return (
      Boolean(filter.searchQuery) ||
      Boolean(filter.startDate) ||
      Boolean(filter.endDate) ||
      filter.paymentMethods.length > 0 ||
      filter.products.length > 0 ||
      filter.minPrice > 0 ||
      filter.maxPrice < 1000 ||
      filter.orderType !== 'all'
    );
  }, [filter]);

  // Filter Drill-down handlers
  const handleFilterByProduct = (productName: string) => {
    setFilter(prev => ({
      ...prev,
      products: [productName],
    }));
  };

  const handleFilterByPayment = (paymentName: string) => {
    setFilter(prev => ({
      ...prev,
      paymentMethods: [paymentName],
    }));
  };

  const handleResetFilters = () => {
    setFilter(DEFAULT_FILTER);
  };

  // CRUD Handlers for Data Table & Import
  const handleUpdateRecord = (updated: SalesRecord) => {
    setRecords(prev => prev.map(r => (r.id === updated.id ? updated : r)));
  };

  const handleDeleteRecord = (id: string) => {
    setRecords(prev => prev.filter(r => r.id !== id));
  };

  const handleAddRecord = (newRow: Omit<SalesRecord, 'id'>) => {
    const created: SalesRecord = {
      ...newRow,
      id: `rec_new_${Date.now()}`,
    };
    setRecords(prev => [created, ...prev]);
  };

  const handleImportRecords = (imported: SalesRecord[]) => {
    setRecords(imported);
    setFilter(DEFAULT_FILTER);
  };

  const handleRestoreDefaultData = () => {
    setRecords(INITIAL_SALES_RECORDS);
    setFilter(DEFAULT_FILTER);
  };

  return (
    <div
      onDragOver={handlePageDragOver}
      onDrop={handlePageDrop}
      className="min-h-screen bg-[#020617] text-slate-100 font-sans antialiased selection:bg-indigo-500 selection:text-white relative overflow-x-hidden"
    >
      
      {/* Background Frosted Glass Mesh Globs */}
      <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/20 rounded-full blur-[140px] pointer-events-none z-0" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-purple-600/15 rounded-full blur-[160px] pointer-events-none z-0" />
      <div className="fixed top-[20%] right-[10%] w-[35%] h-[35%] bg-blue-500/15 rounded-full blur-[120px] pointer-events-none z-0" />

      {/* 1. Header Navigation */}
      <Header
        currentView={currentView}
        onViewChange={setCurrentView}
        totalRecordsCount={records.length}
        filteredRecordsCount={filteredRecords.length}
        totalRevenue={metricSummary.totalRevenue}
        records={filteredRecords}
        onOpenImportModal={() => {
          setDroppedFile(null);
          setIsImportModalOpen(true);
        }}
        onResetFilters={handleResetFilters}
        hasActiveFilters={hasActiveFilters}
      />

      {/* 2. Global Filter Bar */}
      <FilterBar
        filter={filter}
        setFilter={setFilter}
        allProducts={allProducts}
        allPaymentMethods={allPaymentMethods}
        onResetFilters={handleResetFilters}
        hasActiveFilters={hasActiveFilters}
      />

      {/* 3. Main Content Workspace */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 relative z-10">
        
        {/* KPI Cards (Always visible on top of analytics tabs) */}
        <KPICards
          metrics={metricSummary}
          onFilterByProduct={handleFilterByProduct}
          onFilterByPayment={handleFilterByPayment}
        />

        {/* Dynamic View Switcher */}
        {currentView === 'overview' && (
          <OverviewCharts
            timelineData={timelineData}
            productPerformance={productPerformance}
            paymentPerformance={paymentPerformance}
            onFilterByProduct={handleFilterByProduct}
            onFilterByPayment={handleFilterByPayment}
          />
        )}

        {currentView === 'products' && (
          <ProductAnalytics
            products={productPerformance}
            coOccurrences={basketData.coOccurrences}
            onFilterByProduct={handleFilterByProduct}
          />
        )}

        {currentView === 'payment' && (
          <PaymentOrderAnalytics
            payments={paymentPerformance}
            timelineData={timelineData}
            basketData={basketData}
            dayOfWeekData={dayOfWeekData}
            onFilterByPayment={handleFilterByPayment}
          />
        )}

        {currentView === 'custom' && (
          <CustomChartBuilder records={filteredRecords} />
        )}

        {currentView === 'table' && (
          <DataExplorerTable
            records={filteredRecords}
            onUpdateRecord={handleUpdateRecord}
            onDeleteRecord={handleDeleteRecord}
            onAddRecord={handleAddRecord}
          />
        )}

      </main>

      {/* 4. Import / Edit Data Modal */}
      <ImportDataModal
        isOpen={isImportModalOpen}
        onClose={() => {
          setIsImportModalOpen(false);
          setDroppedFile(null);
        }}
        onImportRecords={handleImportRecords}
        onRestoreDefaultData={handleRestoreDefaultData}
        preloadedFile={droppedFile}
      />

      {/* Subtle Footer */}
      <footer className="border-t border-white/10 py-6 text-center text-xs text-slate-500 relative z-10">
        Sales & Orders Interactive Analytics Dashboard • Frosted Glass Design System
      </footer>

    </div>
  );
}
