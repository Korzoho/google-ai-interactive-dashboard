export interface SalesRecord {
  id: string; // Auto-generated internal unique ID
  orderNumber: string;
  product: string;
  price: number;
  date: string; // YYYY-MM-DD
  paymentMethod: 'Credit Card' | 'eWallet' | 'Cash' | 'Debit Card' | string;
}

export interface FilterState {
  searchQuery: string;
  startDate: string;
  endDate: string;
  paymentMethods: string[];
  products: string[];
  minPrice: number;
  maxPrice: number;
  orderType: 'all' | 'single' | 'multi'; // single item order vs multi item order
}

export interface MetricSummary {
  totalRevenue: number;
  totalItemsSold: number;
  totalUniqueOrders: number;
  avgOrderValue: number;
  avgItemPrice: number;
  topProductByRevenue: { name: string; revenue: number; units: number };
  topProductByUnits: { name: string; units: number; revenue: number };
  topPaymentMethod: { name: string; count: number; revenue: number };
  multiItemOrdersCount: number;
  multiItemOrdersPercent: number;
}

export interface ProductPerformance {
  product: string;
  revenue: number;
  unitsSold: number;
  avgPrice: number;
  orderCount: number;
  revenueSharePercent: number;
  paymentBreakdown: Record<string, number>;
}

export interface PaymentPerformance {
  method: string;
  revenue: number;
  count: number;
  percentage: number;
  avgTransaction: number;
}

export interface TimelineDataPoint {
  date: string;
  revenue: number;
  units: number;
  orders: number;
  cumRevenue: number;
  CreditCard: number;
  eWallet: number;
  Cash: number;
  DebitCard: number;
}

export interface CustomChartConfig {
  xAxis: 'date' | 'product' | 'paymentMethod' | 'dayOfWeek' | 'priceBucket';
  yAxis: 'revenue' | 'units' | 'orders' | 'avgPrice';
  chartType: 'bar' | 'line' | 'area' | 'pie' | 'scatter';
  aggregation: 'sum' | 'count' | 'avg';
  sortBy: 'val-desc' | 'val-asc' | 'key-asc' | 'key-desc';
}

export interface BasketSizeDistribution {
  sizeLabel: string;
  count: number;
  revenue: number;
  percentage: number;
}

export interface ProductCoOccurrence {
  productA: string;
  productB: string;
  coOccurrences: number;
}

export type DashboardView = 'overview' | 'products' | 'payment' | 'custom' | 'table';
